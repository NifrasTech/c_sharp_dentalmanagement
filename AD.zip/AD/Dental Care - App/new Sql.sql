﻿
select * from TreatmentHistory

insert into TreatmentHistory (appointID,trtmntID,date) values (2,1,'2019/08/16')
insert into TreatmentHistory (appointID,trtmntID,date) values (4,3,'2019/08/16')

update Appointment set status='Success' where appointID=1

insert into Staff (firstname,lastname,nic,dob,contact,address,designation) values ('Peter', 'Robin', '54646545V', '1960/09/27','03352323','United States', 'Nurse')
update Staff set firstname='Robin',lastname='Hood',nic='54646545V',dob='1960/09/27',contact='03352323',address='United States',designation='Nurse' where Id=2

select * from payment

select Treatment.name, TreatmentHistory.date from
((TreatmentHistory INNER JOIN Treatment on TreatmentHistory.trtmntID=Treatment.trtmntID)
INNER JOIN Appointment ON TreatmentHistory.appointID = Appointment.appointID) where Appointment.patID = 1 and Appointment.docID=2

select Appointment.appointID, Patient.patientID, Patient.firstName +' '+ Patient.lastName as fullname, 
Patient.contactNo, Appointment.date, Appointment.status from Patient INNER JOIN Appointment on 
Patient.patientID = Appointment.patID where date = '2019/08/15' and docID=2 and status='Success'

insert into Users (userName, password, userType) values ('Admin', 'admin', 'Admin')

select userName, Password, userType from Users

select * from Users 


﻿select docID, COUNT (*) FROM Appointment where date='2019/08/20' GROUP BY docID HAVING COUNT(*)<7

select * from Appointment INNER JOIN Patient ON Appointment.patID = Patient.patientID where docID = 1 

insert into Appointment (docID,patID, date, status) VALUES (1, 1, '2019/08/15', 'Pending')
insert into Appointment (docID,patID, date, status) VALUES (1, 2, '2019/08/15', 'Pending')
insert into Appointment (docID,patID, date, status) VALUES (1, 4, '2019/08/15', 'Pending')
insert into Appointment (docID,patID, date, status) VALUES (1, 6, '2019/08/17', 'Pending')

select TreatmentHistory.trtmntID, TreatmentHistory.date ,Treatment.name, Treatment.amount from TreatmentHistory
inner join Treatment on Treatment.trtmntID = TreatmentHistory.trtmntID where appointID = 3

select Patient.firstName +' '+ Patient.lastName as patfullname, Doctor.FirstName+ ' '+ Doctor.LastName as docfullname from Appointment
inner join Patient on Appointment.patID = Patient.patientID 
inner join Doctor on Appointment.docID = Doctor.docID where appointID=2 and Appointment.status='Success'

EXEC getPatandDoc @id=1
EXEC getTreatment @id=3

select Appointment.appointID, Patient.patientID, Patient.firstName +' '+ Patient.lastName as fullname, 
Patient.contactNo, Appointment.date, Appointment.status from Patient INNER JOIN Appointment on 
Patient.patientID = Appointment.patID where date = '2019/08/15' and docID=2 and status='Success'

select * from Payment 
select * from Appointment
select * from Doctor
select * from Treatment
select * from TreatmentHistory

insert into Payment (appointID,amount,date) values (2, 3000, '2019/08/15')



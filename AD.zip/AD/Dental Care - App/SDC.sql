﻿select Doctor.docID, Doctor.FirstName+ ' '+ Doctor.LastName as FullName from Doctor INNER JOIN  Appointment ON Doctor.docID = Appointment.docID

SELECT Doctor.docID, Doctor.FirstName+ ' '+ Doctor.LastName as FullName  FROM  Doctor FULL OUTER JOIN 
(SELECT docID, COUNT(*) AS test from Appointment where date='2019/08/15' GROUP BY docID HAVING COUNT(*)<8)
Appointment ON Doctor.docID = Appointment.docID WHERE Appointment.docID is null


SELECT Doctor.docID, Doctor.FirstName+ ' '+ Doctor.LastName as FullName  FROM  Doctor LEFT JOIN 
Appointment ON Doctor.docID = Appointment.docID 



select * from Appointment

select docID, COUNT (*) FROM Appointment where date='2019/08/15' GROUP BY docID HAVING COUNT(*)<8 

select * from Appointment INNER JOIN Patient ON Appointment.patID = Patient.patientID where docID = 1 

insert into Appointment (docID,patID, date, status) VALUES (1, 1, '2019/08/15', 'Pending')
insert into Appointment (docID,patID, date, status) VALUES (1, 2, '2019/08/15', 'Pending')
insert into Appointment (docID,patID, date, status) VALUES (1, 4, '2019/08/15', 'Pending')
insert into Appointment (docID,patID, date, status) VALUES (1, 6, '2019/08/17', 'Pending')

SELECT Doctor.docID, Doctor.FirstName+ ' '+ Doctor.LastName as FullName  FROM  Doctor LEFT JOIN 
Appointment ON Doctor.docID = Appointment.docID where Appointment.docID is null

SELECT Doctor.docID, Doctor.FirstName+ ' '+ Doctor.LastName as FullName  FROM  Doctor INNER JOIN 
(SELECT docID, COUNT(*) AS test from Appointment where date='2019/08/15' GROUP BY docID HAVING COUNT(*)<8)
Appointment ON Doctor.docID = Appointment.docID UNION SELECT Doctor.docID, Doctor.FirstName+ ' '+ Doctor.LastName as FullName  FROM  Doctor LEFT JOIN 
Appointment ON Doctor.docID = Appointment.docID where Appointment.docID is null

EXEC AvailableDoctors @day = '2019/08/15'
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App
{
    class Appointment
    {
        private int appointid;
        private int docid;
        private int patid;
        private string date;
        private string status;

        public int appointID
        {
            get { return appointid; }
            set { appointid = value; }
        }

        public int docID
        {
            get { return docid; }
            set { docid = value; }
        }

        public int patID
        {
            get { return patid; }
            set { patid = value; }
        }

        public string Date
        {
            get { return date; }
            set { date = value; }
        }

        public string Status
        {
            get { return status; }
            set { status = value; }
        }

        string query;
        Functions function = new Functions();
        public void viewAppointment(DataGridView dataGrid)
        {
            query = "select Appointment.appointID, Patient.patientID, Patient.firstName + ' ' + Patient.lastName as fullname, Patient.contactNo, Appointment.date, Appointment.status from Patient INNER JOIN Appointment on Patient.patientID = Appointment.patID where docID = " + User.userID + " and status = 'Pending' order by date ASC";
            dataGrid.DataSource=function.fillData(query);
        }

        public void viewAppointmentbyDate(DataGridView dataGrid)
        {
            query = "select Appointment.appointID, Patient.patientID, Patient.firstName + ' ' + Patient.lastName as fullname, Patient.contactNo, Appointment.date, Appointment.status from Patient INNER JOIN Appointment on Patient.patientID = Appointment.patID where docID = " + User.userID + " and date='"+date+"' and status = 'Pending' order by date ASC";
            dataGrid.DataSource = function.fillData(query);
        }

        public void addAppointment()
        {
            query = "insert into Appointment (docID,patID, date, status) VALUES ("+docid+ ", " + patid + ", '" + date + "', 'Pending')";
            function.ExecuteQuery(query);
            
            
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dental_Care___App
{
    class Connection
    {
        public static string connection = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\BEngineering\AD\Dental Care - App\Dental Care - App\dbSDC.mdf;Integrated Security=True";
    }
}

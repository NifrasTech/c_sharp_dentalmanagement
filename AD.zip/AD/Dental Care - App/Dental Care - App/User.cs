using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App
{

    class User
    {
        public static string userRole; // Temporary Use
        public static int userID;
        public static string userName;
        public static string password;
    }
}

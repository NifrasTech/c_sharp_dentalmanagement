﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App
{
    class PublicClass
    {
        public static DataGridView dataGrid;

        //Patient Details
        public static int patID;
        public static String patFirstName;
        public static String patLastName;
        public static String patNIC;
        public static String patContact;
        public static String patAddress;

        //Doctor Details
        public static int docID;
        public static string docFirstName;
        public static string docLastName;
        public static string docNIC;
        public static string docDOB;
        public static string docExp;
        public static string docContact;
        public static string docAddress;

        public static int appointID;
        public static string totalParameter;

    }
}

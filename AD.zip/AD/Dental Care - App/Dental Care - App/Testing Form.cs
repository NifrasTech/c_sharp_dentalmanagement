﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App
{
    public partial class Testing_Form : Form
    {
        Validation valid = new Validation();
        public Testing_Form()
        {
            InitializeComponent();
            valid.textBoxMinValue(textBox1);
        }

        Animation anim = new Animation();
        private void Testing_Form_Load(object sender, EventArgs e)
        {
             string sql = "select docID, FirstName, LastName, NIC, DOB, DATEDIFF(YEAR, exp, GETDATE()) as exp, contact, address from Doctor";
            DataTable dt = new DataTable();
            dt = new Functions().fillData(sql);

            dataGridView1.DataSource = dt;

            //        for (int i = 0; i < dt.Rows.Count; i++)
            //        {

            //            arrDoc[i,1]= new int[,] { { Convert.ToInt32(dt.Rows[i][5].ToString()) }, { Convert.ToInt32(dt.Rows[i][5].ToString())}
            //};

            //        }

            //        //sorting
            //        int temp;
            //        for (int j = 0; j <= arrDoc.Length - 2; j++)
            //        {
            //            for (int i = 0; i <= arrDoc.Length - 2; i++)
            //            {
            //                if (arrDoc[i] < arrDoc[i + 1])
            //                {
            //                    temp = arrDoc[i + 1];
            //                    arrDoc[i + 1] = arrDoc[i];
            //                    arrDoc[i] = temp;
            //                }
            //            }
            //        }

            //        MessageBox.Show(string.Join("\n",arrDoc));
            //    }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int row=0, 
                col=0;
            string sql = "select docID, FirstName, LastName, NIC, DOB, DATEDIFF(YEAR, exp, GETDATE()) as exp, contact, address from Doctor";
            DataTable dt = new DataTable();
            dt = new Functions().fillData(sql);

            string[,] arrdoc = new string[dt.Rows.Count, dt.Columns.Count];

            for (row = 0; row < dt.Rows.Count; ++row)
            {
                for (col = 0; col < dt.Columns.Count; col++)
                {
                    arrdoc[row, col] = dt.Rows[row][col].ToString();
                }
            }
            MessageBox.Show(arrdoc[0,0]);
        }
    }

}

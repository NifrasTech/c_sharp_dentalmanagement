﻿namespace Dental_Care___App
{


    public partial class dsetIncome
    {
    }
}

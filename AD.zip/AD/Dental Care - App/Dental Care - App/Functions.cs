﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Dental_Care___App
{
    class Functions : Connection
    {
        SqlConnection conn = new SqlConnection(connection);
        SqlCommand sqlCMD;
        SqlDataAdapter sqlDA;

        public void ExecuteQuery(string query)
        {
            try
            { 
                sqlCMD = new SqlCommand(query, conn);
                conn.Open();
                sqlCMD.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        public DataTable fillData(string query)
        {
            DataTable dTable = new DataTable();
            try
            {
                sqlDA = new SqlDataAdapter(query, conn);
                conn.Open();
                sqlDA.Fill(dTable);
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            return dTable;
        }
    }
}

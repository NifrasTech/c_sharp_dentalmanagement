﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dental_Care___App
{
    class TreatmentHistory
    {
        private int id;
        private int trtmntid;
        private int appointid;
        private string date;

        public int ID
        {
            get { return id; }
            set { id = value; }
        }

        public int trtmntID
        {
            get { return trtmntid; }
            set { trtmntid = value; }
        }

        public int appointID
        {
            get { return appointid; }
            set { appointid = value; }
        }

        public string Date
        {
            get { return date; }
            set { date = value; }
        }

        string query;
        string qry;
        Functions function = new Functions();
        Animation animation = new Animation();
        public void saveTreatmentHistory()
        {
            query = "insert into TreatmentHistory (appointID,trtmntID,date) values ("+appointid+","+trtmntid+",'"+date+"')";
            qry = "update Appointment set status='Success' where appointID="+appointid+"";
            function.ExecuteQuery(query);
            function.ExecuteQuery(qry);
            animation.messageBox("Successfully Added",true);
        }

        //public void viewTreatmentHistory()
        //{

        //}
    }
}

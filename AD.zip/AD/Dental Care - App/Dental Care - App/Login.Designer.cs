﻿namespace Dental_Care___App
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            BunifuAnimatorNS.Animation animation2 = new BunifuAnimatorNS.Animation();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnLogin = new Bunifu.Framework.UI.BunifuFlatButton();
            this.loginTransition = new BunifuAnimatorNS.BunifuTransition(this.components);
            this.btnClose = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.pbDental = new System.Windows.Forms.PictureBox();
            this.bunifuGradientPanel2 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.btnManager = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnFrontOfficer = new Bunifu.Framework.UI.BunifuFlatButton();
            this.pnlForm = new System.Windows.Forms.Panel();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pbUser = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.btnDoctor = new Bunifu.Framework.UI.BunifuFlatButton();
            this.lblMessage = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbDental)).BeginInit();
            this.bunifuGradientPanel2.SuspendLayout();
            this.pnlForm.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbUser)).BeginInit();
            this.SuspendLayout();
            // 
            // btnLogin
            // 
            this.btnLogin.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnLogin.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnLogin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLogin.BorderRadius = 7;
            this.btnLogin.ButtonText = "LOGIN";
            this.btnLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.loginTransition.SetDecoration(this.btnLogin, BunifuAnimatorNS.DecorationType.None);
            this.btnLogin.DisabledColor = System.Drawing.Color.Gray;
            this.btnLogin.Iconcolor = System.Drawing.Color.Transparent;
            this.btnLogin.Iconimage = null;
            this.btnLogin.Iconimage_right = null;
            this.btnLogin.Iconimage_right_Selected = null;
            this.btnLogin.Iconimage_Selected = null;
            this.btnLogin.IconMarginLeft = 0;
            this.btnLogin.IconMarginRight = 0;
            this.btnLogin.IconRightVisible = true;
            this.btnLogin.IconRightZoom = 0D;
            this.btnLogin.IconVisible = true;
            this.btnLogin.IconZoom = 90D;
            this.btnLogin.IsTab = false;
            this.btnLogin.Location = new System.Drawing.Point(52, 403);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Normalcolor = System.Drawing.Color.DodgerBlue;
            this.btnLogin.OnHovercolor = System.Drawing.SystemColors.MenuHighlight;
            this.btnLogin.OnHoverTextColor = System.Drawing.Color.White;
            this.btnLogin.selected = false;
            this.btnLogin.Size = new System.Drawing.Size(280, 41);
            this.btnLogin.TabIndex = 3;
            this.btnLogin.Text = "LOGIN";
            this.btnLogin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnLogin.Textcolor = System.Drawing.Color.White;
            this.btnLogin.TextFont = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // loginTransition
            // 
            this.loginTransition.AnimationType = BunifuAnimatorNS.AnimationType.Mosaic;
            this.loginTransition.Cursor = null;
            animation2.AnimateOnlyDifferences = true;
            animation2.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.BlindCoeff")));
            animation2.LeafCoeff = 0F;
            animation2.MaxTime = 1F;
            animation2.MinTime = 0F;
            animation2.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.MosaicCoeff")));
            animation2.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation2.MosaicShift")));
            animation2.MosaicSize = 20;
            animation2.Padding = new System.Windows.Forms.Padding(30);
            animation2.RotateCoeff = 0F;
            animation2.RotateLimit = 0F;
            animation2.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.ScaleCoeff")));
            animation2.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.SlideCoeff")));
            animation2.TimeCoeff = 0F;
            animation2.TransparencyCoeff = 0F;
            this.loginTransition.DefaultAnimation = animation2;
            this.loginTransition.MaxAnimationTime = 3000;
            // 
            // btnClose
            // 
            this.btnClose.Activecolor = System.Drawing.Color.Transparent;
            this.btnClose.BackColor = System.Drawing.Color.Transparent;
            this.btnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnClose.BorderRadius = 7;
            this.btnClose.ButtonText = "X";
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.loginTransition.SetDecoration(this.btnClose, BunifuAnimatorNS.DecorationType.None);
            this.btnClose.DisabledColor = System.Drawing.SystemColors.GrayText;
            this.btnClose.Iconcolor = System.Drawing.Color.Transparent;
            this.btnClose.Iconimage = null;
            this.btnClose.Iconimage_right = null;
            this.btnClose.Iconimage_right_Selected = null;
            this.btnClose.Iconimage_Selected = null;
            this.btnClose.IconMarginLeft = 0;
            this.btnClose.IconMarginRight = 0;
            this.btnClose.IconRightVisible = true;
            this.btnClose.IconRightZoom = 0D;
            this.btnClose.IconVisible = true;
            this.btnClose.IconZoom = 90D;
            this.btnClose.IsTab = false;
            this.btnClose.Location = new System.Drawing.Point(344, 7);
            this.btnClose.Name = "btnClose";
            this.btnClose.Normalcolor = System.Drawing.Color.Transparent;
            this.btnClose.OnHovercolor = System.Drawing.Color.Transparent;
            this.btnClose.OnHoverTextColor = System.Drawing.Color.Red;
            this.btnClose.selected = false;
            this.btnClose.Size = new System.Drawing.Size(39, 35);
            this.btnClose.TabIndex = 46;
            this.btnClose.Text = "X";
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClose.Textcolor = System.Drawing.SystemColors.HotTrack;
            this.btnClose.TextFont = new System.Drawing.Font("Corbel", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.loginTransition.SetDecoration(this.bunifuGradientPanel1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(-2, 527);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(393, 20);
            this.bunifuGradientPanel1.TabIndex = 49;
            // 
            // pbDental
            // 
            this.pbDental.BackColor = System.Drawing.Color.Transparent;
            this.pbDental.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.loginTransition.SetDecoration(this.pbDental, BunifuAnimatorNS.DecorationType.None);
            this.pbDental.Image = ((System.Drawing.Image)(resources.GetObject("pbDental.Image")));
            this.pbDental.Location = new System.Drawing.Point(107, 11);
            this.pbDental.Name = "pbDental";
            this.pbDental.Size = new System.Drawing.Size(177, 179);
            this.pbDental.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbDental.TabIndex = 47;
            this.pbDental.TabStop = false;
            // 
            // bunifuGradientPanel2
            // 
            this.bunifuGradientPanel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel2.BackgroundImage")));
            this.bunifuGradientPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel2.Controls.Add(this.pbDental);
            this.loginTransition.SetDecoration(this.bunifuGradientPanel2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuGradientPanel2.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bunifuGradientPanel2.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.bunifuGradientPanel2.GradientTopLeft = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.bunifuGradientPanel2.GradientTopRight = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.bunifuGradientPanel2.Location = new System.Drawing.Point(-4, -3);
            this.bunifuGradientPanel2.Name = "bunifuGradientPanel2";
            this.bunifuGradientPanel2.Quality = 10;
            this.bunifuGradientPanel2.Size = new System.Drawing.Size(395, 192);
            this.bunifuGradientPanel2.TabIndex = 49;
            // 
            // btnManager
            // 
            this.btnManager.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnManager.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnManager.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnManager.BorderRadius = 7;
            this.btnManager.ButtonText = "Manager";
            this.btnManager.Cursor = System.Windows.Forms.Cursors.Hand;
            this.loginTransition.SetDecoration(this.btnManager, BunifuAnimatorNS.DecorationType.None);
            this.btnManager.DisabledColor = System.Drawing.Color.Gray;
            this.btnManager.Iconcolor = System.Drawing.Color.Transparent;
            this.btnManager.Iconimage = null;
            this.btnManager.Iconimage_right = null;
            this.btnManager.Iconimage_right_Selected = null;
            this.btnManager.Iconimage_Selected = null;
            this.btnManager.IconMarginLeft = 0;
            this.btnManager.IconMarginRight = 0;
            this.btnManager.IconRightVisible = true;
            this.btnManager.IconRightZoom = 0D;
            this.btnManager.IconVisible = true;
            this.btnManager.IconZoom = 90D;
            this.btnManager.IsTab = false;
            this.btnManager.Location = new System.Drawing.Point(24, 480);
            this.btnManager.Name = "btnManager";
            this.btnManager.Normalcolor = System.Drawing.Color.DodgerBlue;
            this.btnManager.OnHovercolor = System.Drawing.SystemColors.MenuHighlight;
            this.btnManager.OnHoverTextColor = System.Drawing.Color.White;
            this.btnManager.selected = false;
            this.btnManager.Size = new System.Drawing.Size(109, 41);
            this.btnManager.TabIndex = 3;
            this.btnManager.Text = "Manager";
            this.btnManager.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnManager.Textcolor = System.Drawing.Color.White;
            this.btnManager.TextFont = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManager.Click += new System.EventHandler(this.btnManager_Click);
            // 
            // btnFrontOfficer
            // 
            this.btnFrontOfficer.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnFrontOfficer.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnFrontOfficer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnFrontOfficer.BorderRadius = 7;
            this.btnFrontOfficer.ButtonText = "Officer";
            this.btnFrontOfficer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.loginTransition.SetDecoration(this.btnFrontOfficer, BunifuAnimatorNS.DecorationType.None);
            this.btnFrontOfficer.DisabledColor = System.Drawing.Color.Gray;
            this.btnFrontOfficer.Iconcolor = System.Drawing.Color.Transparent;
            this.btnFrontOfficer.Iconimage = null;
            this.btnFrontOfficer.Iconimage_right = null;
            this.btnFrontOfficer.Iconimage_right_Selected = null;
            this.btnFrontOfficer.Iconimage_Selected = null;
            this.btnFrontOfficer.IconMarginLeft = 0;
            this.btnFrontOfficer.IconMarginRight = 0;
            this.btnFrontOfficer.IconRightVisible = true;
            this.btnFrontOfficer.IconRightZoom = 0D;
            this.btnFrontOfficer.IconVisible = true;
            this.btnFrontOfficer.IconZoom = 90D;
            this.btnFrontOfficer.IsTab = false;
            this.btnFrontOfficer.Location = new System.Drawing.Point(139, 480);
            this.btnFrontOfficer.Name = "btnFrontOfficer";
            this.btnFrontOfficer.Normalcolor = System.Drawing.Color.DodgerBlue;
            this.btnFrontOfficer.OnHovercolor = System.Drawing.SystemColors.MenuHighlight;
            this.btnFrontOfficer.OnHoverTextColor = System.Drawing.Color.White;
            this.btnFrontOfficer.selected = false;
            this.btnFrontOfficer.Size = new System.Drawing.Size(109, 41);
            this.btnFrontOfficer.TabIndex = 3;
            this.btnFrontOfficer.Text = "Officer";
            this.btnFrontOfficer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnFrontOfficer.Textcolor = System.Drawing.Color.White;
            this.btnFrontOfficer.TextFont = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFrontOfficer.Click += new System.EventHandler(this.btnFrontOfficer_Click);
            // 
            // pnlForm
            // 
            this.pnlForm.Controls.Add(this.txtUserName);
            this.pnlForm.Controls.Add(this.txtPassword);
            this.pnlForm.Controls.Add(this.pictureBox1);
            this.pnlForm.Controls.Add(this.pbUser);
            this.pnlForm.Controls.Add(this.panel1);
            this.pnlForm.Controls.Add(this.panel10);
            this.loginTransition.SetDecoration(this.pnlForm, BunifuAnimatorNS.DecorationType.None);
            this.pnlForm.Location = new System.Drawing.Point(31, 216);
            this.pnlForm.Name = "pnlForm";
            this.pnlForm.Size = new System.Drawing.Size(306, 178);
            this.pnlForm.TabIndex = 50;
            // 
            // txtUserName
            // 
            this.txtUserName.BackColor = System.Drawing.Color.White;
            this.txtUserName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.loginTransition.SetDecoration(this.txtUserName, BunifuAnimatorNS.DecorationType.None);
            this.txtUserName.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUserName.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.txtUserName.Location = new System.Drawing.Point(65, 48);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(236, 26);
            this.txtUserName.TabIndex = 1;
            this.txtUserName.Tag = "User Name";
            this.txtUserName.Text = "User Name";
            this.txtUserName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtPassword
            // 
            this.txtPassword.BackColor = System.Drawing.Color.White;
            this.txtPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.loginTransition.SetDecoration(this.txtPassword, BunifuAnimatorNS.DecorationType.None);
            this.txtPassword.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.txtPassword.Location = new System.Drawing.Point(60, 121);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '•';
            this.txtPassword.Size = new System.Drawing.Size(237, 26);
            this.txtPassword.TabIndex = 2;
            this.txtPassword.Tag = "Password";
            this.txtPassword.Text = "Password";
            this.txtPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.loginTransition.SetDecoration(this.pictureBox1, BunifuAnimatorNS.DecorationType.None);
            this.pictureBox1.Location = new System.Drawing.Point(21, 125);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(33, 23);
            this.pictureBox1.TabIndex = 53;
            this.pictureBox1.TabStop = false;
            // 
            // pbUser
            // 
            this.pbUser.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbUser.BackgroundImage")));
            this.pbUser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.loginTransition.SetDecoration(this.pbUser, BunifuAnimatorNS.DecorationType.None);
            this.pbUser.Location = new System.Drawing.Point(29, 49);
            this.pbUser.Name = "pbUser";
            this.pbUser.Size = new System.Drawing.Size(24, 28);
            this.pbUser.TabIndex = 54;
            this.pbUser.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.loginTransition.SetDecoration(this.panel1, BunifuAnimatorNS.DecorationType.None);
            this.panel1.Location = new System.Drawing.Point(60, 150);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(237, 1);
            this.panel1.TabIndex = 51;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.loginTransition.SetDecoration(this.panel10, BunifuAnimatorNS.DecorationType.None);
            this.panel10.Location = new System.Drawing.Point(64, 77);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(237, 1);
            this.panel10.TabIndex = 52;
            // 
            // btnDoctor
            // 
            this.btnDoctor.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnDoctor.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnDoctor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDoctor.BorderRadius = 7;
            this.btnDoctor.ButtonText = "Doctor";
            this.btnDoctor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.loginTransition.SetDecoration(this.btnDoctor, BunifuAnimatorNS.DecorationType.None);
            this.btnDoctor.DisabledColor = System.Drawing.Color.Gray;
            this.btnDoctor.Iconcolor = System.Drawing.Color.Transparent;
            this.btnDoctor.Iconimage = null;
            this.btnDoctor.Iconimage_right = null;
            this.btnDoctor.Iconimage_right_Selected = null;
            this.btnDoctor.Iconimage_Selected = null;
            this.btnDoctor.IconMarginLeft = 0;
            this.btnDoctor.IconMarginRight = 0;
            this.btnDoctor.IconRightVisible = true;
            this.btnDoctor.IconRightZoom = 0D;
            this.btnDoctor.IconVisible = true;
            this.btnDoctor.IconZoom = 90D;
            this.btnDoctor.IsTab = false;
            this.btnDoctor.Location = new System.Drawing.Point(254, 480);
            this.btnDoctor.Name = "btnDoctor";
            this.btnDoctor.Normalcolor = System.Drawing.Color.DodgerBlue;
            this.btnDoctor.OnHovercolor = System.Drawing.SystemColors.MenuHighlight;
            this.btnDoctor.OnHoverTextColor = System.Drawing.Color.White;
            this.btnDoctor.selected = false;
            this.btnDoctor.Size = new System.Drawing.Size(109, 41);
            this.btnDoctor.TabIndex = 3;
            this.btnDoctor.Text = "Doctor";
            this.btnDoctor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDoctor.Textcolor = System.Drawing.Color.White;
            this.btnDoctor.TextFont = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDoctor.Click += new System.EventHandler(this.btnDoctor_Click);
            // 
            // lblMessage
            // 
            this.lblMessage.BackColor = System.Drawing.Color.Red;
            this.loginTransition.SetDecoration(this.lblMessage, BunifuAnimatorNS.DecorationType.None);
            this.lblMessage.Font = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.ForeColor = System.Drawing.Color.White;
            this.lblMessage.Location = new System.Drawing.Point(0, 447);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(390, 81);
            this.lblMessage.TabIndex = 52;
            this.lblMessage.Text = "Error Message";
            this.lblMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(390, 547);
            this.Controls.Add(this.pnlForm);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.bunifuGradientPanel2);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.btnDoctor);
            this.Controls.Add(this.btnFrontOfficer);
            this.Controls.Add(this.btnManager);
            this.loginTransition.SetDecoration(this, BunifuAnimatorNS.DecorationType.None);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.pbDental)).EndInit();
            this.bunifuGradientPanel2.ResumeLayout(false);
            this.pnlForm.ResumeLayout(false);
            this.pnlForm.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbUser)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuFlatButton btnLogin;
        private BunifuAnimatorNS.BunifuTransition loginTransition;
        private Bunifu.Framework.UI.BunifuFlatButton btnClose;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        private System.Windows.Forms.PictureBox pbDental;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel2;
        private Bunifu.Framework.UI.BunifuFlatButton btnManager;
        private Bunifu.Framework.UI.BunifuFlatButton btnFrontOfficer;
        private System.Windows.Forms.Panel pnlForm;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pbUser;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtUserName;
        private Bunifu.Framework.UI.BunifuFlatButton btnDoctor;
        private System.Windows.Forms.Label lblMessage;
    }
}


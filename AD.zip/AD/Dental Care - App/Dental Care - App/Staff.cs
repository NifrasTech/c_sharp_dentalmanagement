﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App
{
    class Staff
    {
        private int id;
        private string firstname;
        private string lastname;
        private string nic;
        private string dob;
        private string contact;
        private string address;
        private string designation;
        public static string username;

        public int ID
        {
            get { return id; }
            set { id = value; }
        }

        public string FirstName
        {
            get { return firstname; }
            set { firstname = value; }
        }

        public string LastName
        {
            get { return lastname; }
            set { lastname = value; }
        }

        public string NIC
        {
            get { return nic; }
            set { nic = value; }
        }

        public string DOB
        {
            get { return dob; }
            set { dob = value; }
        }

        public string Contact
        {
            get { return contact; }
            set { contact = value; }
        }

        public string Address
        {
            get { return address; }
            set { address = value; }
        }

        public string Designation
        {
            get { return designation; }
            set { designation = value; }
        }


        string query;
        Functions function = new Functions();
        Animation animation = new Animation();
        public void viewStaff(DataGridView dataGrid)
        {
            query = "select Id,firstname,lastname,designation,contact  from Staff";
            DataTable dTable = new DataTable();
            dTable = function.fillData(query);
            dataGrid.DataSource = dTable;
        }

        public void addStaff()
        {
            query = "insert into Staff (firstname,lastname,nic,dob,contact,address,designation) values ('"+firstname+ "', '" + lastname + "', '" + nic + "', '" + dob + "','" + contact + "','" + address + "', '" + designation + "')";
            function.ExecuteQuery(query);
            viewStaff(PublicClass.dataGrid);

            if(designation=="Manager")
            {
                string query2 = "insert into Users (userName, password,userType) values ('" + username + "','password','Manager')";
                function.ExecuteQuery(query2);
                animation.messageBox("Saved Successfully", true);
            }
            else if (designation=="Front Officer")
            {
                string query3 = "insert into Users (userName, password,userType) values ('" + username + "','password','Front Officer')";
                function.ExecuteQuery(query3);
                animation.messageBox("Saved Successfully", true);
            }

           
        }

        public void deleteStaff()
        {
            string query2;
            query = "delete from staff where id="+id+"";
            if(designation == "Manager")
            { 
                query2 = "delete from Users where userName='MAN" + id.ToString() + "'";
                function.ExecuteQuery(query2);
                function.ExecuteQuery(query);
            }
            else if (designation=="Front Officer")
            {
                query2 = "delete from Users where userName='OFF" + id.ToString() + "'";
                function.ExecuteQuery(query2);
                function.ExecuteQuery(query);
            }
            else
            {
                function.ExecuteQuery(query);
            }

            viewStaff(PublicClass.dataGrid);
            animation.messageBox("Deleted Successfully", true);
        }

        public void updateStaff()
        {
            //DateTime date = Convert.ToDateTime(dob);
            query = "update Staff set firstname='"+firstname+ "',lastname='" + lastname + "',nic='" + nic + "',dob='" + dob + "',contact='" + contact + "',address='" + address + "',designation='" + designation + "' where Id=" + id + "";
            function.ExecuteQuery(query);
            viewStaff(PublicClass.dataGrid);
            animation.messageBox("Updated Successfully", true);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App
{
    public partial class Form1 : Form
    {
        Validation validation = new Validation();
        Animation animation = new Animation();
        Functions function = new Functions();
        public Form1()
        {
            InitializeComponent();
            validation.placeHolder(pnlForm);
        }

        frmApplication application = new frmApplication(); // this form will be opened after the login
        int messageTop;

        private void Form1_Load(object sender, EventArgs e)
        {
            pbDental.Hide(); // hiding this picture box of Logo to Animation
            messageTop = lblMessage.Top;
            lblMessage.Top = this.Height;
            btnDoctor.Visible = false;
            btnManager.Visible = false;
            btnFrontOfficer.Visible = false;
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            loginTransition.ShowSync(pbDental);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnManager_Click(object sender, EventArgs e)
        {
            User.userRole = "Manager";
            application.ShowDialog();
        }

        private void btnFrontOfficer_Click(object sender, EventArgs e)
        {
            User.userRole = "Front Officer";
            application.ShowDialog();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (validation.loginEmpty(pnlForm,lblMessage))
            {
                DataTable dataTable = new DataTable();
                string query = "select userName, Password, userType from Users where userName='" + txtUserName.Text.Trim() +"'";
                dataTable = function.fillData(query);

                if(dataTable.Rows.Count==0)
                {
                    txtUserName.Focus();
                    lblMessage.Text = "User is not Exist";
                    animation.LoginMessage(lblMessage, messageTop);
                }
                else
                {
                    if (dataTable.Rows[0].ItemArray[1].ToString()==txtPassword.Text.Trim())
                    {
                        User.userName = dataTable.Rows[0].ItemArray[0].ToString();
                        User.password = dataTable.Rows[0].ItemArray[1].ToString();
                        User.userRole = dataTable.Rows[0].ItemArray[2].ToString();

                        if(User.userRole=="Admin")
                        {
                            application.ShowDialog();
                        }
                        else if (User.userRole=="Doctor")
                        {
                            int id = validation.returnID(txtUserName.Text);
                            User.userID = id;
                            application.ShowDialog();
                        }
                        else if(User.userRole == "Front Officer")
                        {
                            int id = validation.returnID(txtUserName.Text);
                            User.userID = id;
                            application.ShowDialog();
                        }
                        else if (User.userRole == "Manager")
                        {
                            int id = validation.returnID(txtUserName.Text);
                            User.userID = id;
                            application.ShowDialog();
                        }

                        validation.clearAllTextBox(pnlForm);
                    }
                    else
                    {
                        txtPassword.Focus();
                        lblMessage.Text = "Password is Incorret";
                        animation.LoginMessage(lblMessage,messageTop);
                    }
                }
            }
            else
            {
                animation.LoginMessage(lblMessage, messageTop);
            }
        }

        private void btnDoctor_Click(object sender, EventArgs e)
        {
            User.userRole = "Doctor";
            User.userID = 2;
            application.ShowDialog();
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            int id=validation.returnID(txtUserName.Text);
            MessageBox.Show(id.ToString());
        }
    }
}

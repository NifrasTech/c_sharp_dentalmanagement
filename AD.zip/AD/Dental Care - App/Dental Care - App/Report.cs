﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App
{
    public partial class Report : Form
    {
        Functions function = new Functions();
        public Report()
        {
            InitializeComponent();
        }

        private void Report_Load(object sender, EventArgs e)
        {
            this.reportViewer1.RefreshReport();


            ReportParameterCollection reportPar = new ReportParameterCollection();
            reportPar.Add(new ReportParameter("ReportParameter1", "Rs."+PublicClass.totalParameter));
            this.reportViewer1.LocalReport.SetParameters(reportPar);


            DataTable dtatble = new DataTable();
            string query = "EXEC getTreatment @id="+PublicClass.appointID+"";
            dtatble = function.fillData(query);
            dtTreatmentBindingSource.DataSource = dtatble;
            query = "EXEC getPatandDoc @id=" + PublicClass.appointID + "";
            dtatble = function.fillData(query);
            dtFullnameBindingSource.DataSource = dtatble;
            this.reportViewer1.RefreshReport();
        }
    }
}

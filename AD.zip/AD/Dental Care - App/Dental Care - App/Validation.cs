﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App
{
    class Validation
    {
        Animation animation = new Animation();
        Functions function = new Functions();

//===============================================================================================

        //---------------- Text Box Empty Validation ------------------
        public bool textBoxEmpty(Panel parentForm )
        {
            foreach (var ctrl in parentForm.Controls)
            {
                var txtBox = ctrl as TextBox;
                if (txtBox != null)
                {
                    string txt = txtBox.Tag.ToString();
                    if (txtBox.Text.Trim() == txt || txtBox.Text.Trim() == "")
                    {
                        animation.messageBox(txt + " Cannot Be Empty", false);
                        txtBox.Focus();
                        return false;
                    }
                }
            }
            return true;
        }
        //---------------- Text Box Empty Validation Ends Here ------------------

//===============================================================================================

        //---------------- Text Box Minimum Value ------------------
        public void textBoxMinValue(TextBox txtBox)
        {
            var txtLeaved = new EventHandler(textBoxLeave);
            txtBox.Leave += txtLeaved;
        }

        void textBoxLeave(object sender, EventArgs e)
        {
            var textBox = (TextBox)sender;
            if (textBox.Text.Length <= 10)
            {
                textBox.Focus();
                MessageBox.Show("Error");
            }
        }
        //---------------- Text Box Minimum Value Coding ends here ------------------

//===============================================================================================

        //---------------- Text Box that accept only Numbers validation ------------------
        public void numbersOnly(TextBox txtBox)
        {
            var txtKeyPress = new KeyPressEventHandler(textKeyPress);
            txtBox.KeyPress += textKeyPress;
        }

        void textKeyPress(Object sender, KeyPressEventArgs e)
        {
            Char chr = e.KeyChar;
            if(!Char.IsDigit(chr) && chr!=8)
            {
                e.Handled = true;
            }

        }

        //---------------- Text Box that accept only Numbers validation Ends here ---------------

//===============================================================================================

        //---------------- Captitalize Each Word Starts Here ------------------
        public void textCase(Panel panelForm)
        {
            var txtLeaved = new EventHandler(textLeave);
            foreach (var ctrl in panelForm.Controls)
            {
                var txtBox = ctrl as TextBox;
                if (txtBox != null)
                    txtBox.Leave += textLeave;
            }
        }

        void textLeave(object sender, EventArgs e)
        {

            var textBox = (TextBox)sender;
            if (textBox.Text != "")
            {
                textBox.Text = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(textBox.Text);
                textBox.Select(textBox.Text.Length, 0);
            }
        }

        //---------------- Captitalize Each Word Ends Here ------------------

//===============================================================================================

        //---------------- Place Holder Validation Starts Here ------------------
        public void placeHolder(Panel pnlForm)
        {
            //var txtEntered = new EventHandler(txtEnter);
            foreach (var ctrl in pnlForm.Controls)
            {
                var txtBox = ctrl as TextBox;
                if (txtBox != null)
                    txtBox.Enter += txtEnter;
            }

            //var txtLeaved = new EventHandler(txtLeave);
            foreach (var ctrl in pnlForm.Controls)
            {
                var txtBox = ctrl as TextBox;
                if (txtBox != null)
                    txtBox.Leave += txtLeave;
            }
        }

        void txtEnter(object sender, EventArgs e)
        {

            var textBox = (TextBox)sender;

            if (textBox.Text == textBox.Tag.ToString())
            {
                textBox.Text = "";
                textBox.ForeColor = SystemColors.HotTrack;
            }
        }

        void txtLeave(object sender, EventArgs e)
        {

            var textBox = (TextBox)sender;
            if (textBox.Text.Trim() == "")
            {
                textBox.Text = textBox.Tag.ToString();
                textBox.ForeColor = SystemColors.ControlDark;
            }
        }

        //---------------- Place Holder Validation Ends Here ------------------


//===============================================================================================

        //---------------- Clear All Text Box ------------------
        public void clearAllTextBox(Panel pnlForm)
        {
            foreach (var ctrl in pnlForm.Controls)
            {
                var txtBox = ctrl as TextBox;
                if (txtBox != null)
                {
                    txtBox.Text = txtBox.Tag.ToString();
                    txtBox.ForeColor = SystemColors.ControlDark;
                }
            }
        }
        //---------------- Clear All Text Box Ends here ------------------

//===============================================================================================

        //Set text box color

        public void setTextBoxColor(Panel pnlForm)
        {
            foreach (var ctrl in pnlForm.Controls)
            {
                var txtBox = ctrl as TextBox;
                if (txtBox != null)
                {
                    txtBox.ForeColor = SystemColors.HotTrack;
                }
            }
        }


//===============================================================================================

        //---------------- Disable all textBox ------------------
        public void disableTextBox(Panel pnlForm)
        {
            foreach (var ctrl in pnlForm.Controls)
            {
                var txtBox = ctrl as TextBox;
                if (txtBox != null)
                {
                    txtBox.Enabled = false;
                }
            }
        }
        //---------------- Disable all textBox Ends here ------------------

//===============================================================================================

        //---------------- Enable all textBox ------------------
        public void EnableTextBox(Panel pnlForm)
        {
            foreach (var ctrl in pnlForm.Controls)
            {
                var txtBox = ctrl as TextBox;
                if (txtBox != null)
                {
                    txtBox.Enabled = true;
                }
            }
        }
        //---------------- Enable all textBox Ends here ------------------

//===============================================================================================


        public void GenerateID(TextBox textBox, string query)
        {
            int intID;
            string id;

            DataTable dTable = new DataTable();

            dTable = function.fillData(query);
            id = dTable.Rows[0].ItemArray[0].ToString();

            if (id != "")
            {
                intID = Convert.ToInt32(id);
                intID++;

                textBox.Text = intID.ToString();
            }
            else
            {
                textBox.Text = "1";
            }
        }

        public string GeneratePassword()
        {
            int length = 6;
            const string valid = "ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789";
            StringBuilder sBuilder = new StringBuilder();
            Random random = new Random();

            while (0 < length--)
            {
                sBuilder.Append(valid[random.Next(valid.Length)]);
            }
            return sBuilder.ToString();
        }

        public int returnID(string text)
        {
            string numbers = string.Empty;

            foreach (char c in text)
            {
                if (Char.IsNumber(c))
                {
                    numbers += c;
                }
            }
            return Convert.ToInt32(numbers);
        }

        public bool loginEmpty(Panel parentForm, Label label)
        {
            foreach (var ctrl in parentForm.Controls)
            {
                var txtBox = ctrl as TextBox;
                if (txtBox != null)
                {
                    string txt = txtBox.Tag.ToString();
                    if (txtBox.Text.Trim() == txt || txtBox.Text.Trim() == "")
                    {
                        txtBox.Focus();
                        label.Text = txt + " Cannot be Empty";
                        return false;
                    }
                }
            }
            return true;
        }
    }
}

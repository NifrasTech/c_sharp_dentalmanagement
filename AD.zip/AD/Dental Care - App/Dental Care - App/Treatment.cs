﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App
{
    class Treatment
    {
        private int id;
        private string name;
        private decimal amount;

        public int ID
        {
            get { return id; }
            set { id = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public decimal Amount
        {
            get { return amount; }
            set { amount = value; }
        }

        Functions function = new Functions();
        Animation animation = new Animation();

        string query;

        public void saveTreatment()
        {
            query = "insert into Treatment (name, amount) values ('" + name + "', " + amount + ")";
            function.ExecuteQuery(query);
            viewTreatment(PublicClass.dataGrid);
            animation.messageBox("Successfully Save", true);
        }


        public void viewTreatment(DataGridView dataGrid)
        {
            query = "select * from Treatment";
            DataTable dTable = new DataTable();
            dTable = function.fillData(query);
            dataGrid.DataSource = dTable;
        }

        public void deleteTreatment()
        {
            query = "delete from Treatment where trtmntID = " + id + "";
            function.ExecuteQuery(query);
            viewTreatment(PublicClass.dataGrid);
            animation.messageBox("Successfully Deleted", true);
        }

        public void updateTreatment()
        {
            query = "update Treatment set name='"+name+ "', amount=" + amount + " where trtmntID=" + id + "";
            function.ExecuteQuery(query);
            viewTreatment(PublicClass.dataGrid);
            animation.messageBox("Successfully Updated", true);
        }
    }
}

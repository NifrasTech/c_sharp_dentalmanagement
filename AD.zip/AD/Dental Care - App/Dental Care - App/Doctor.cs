using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App
{
    
    class Doctor
    {
        private int id;
        private string firstname;
        private string lastname;
        private string nic;
        private string dob;
        private string exp;
        private string contact;
        private string address;
        public static TextBox txtID;

        public int ID
        {
            get { return id; }
            set { id = value; }
        }

        public string FirstName
        {
            get { return firstname; }
            set { firstname = value; }
        }

        public string LastName
        {
            get { return lastname; }
            set { lastname = value; }
        }

        public string NIC
        {
            get { return nic; }
            set { nic = value; }
        }

        public string DOB
        {
            get { return dob; }
            set { dob = value; }
        }

        public string Exp
        {
            get { return exp; }
            set { exp = value; }
        }

        public string Contact
        {
            get { return contact; }
            set { contact = value; }
        }

        public string Address
        {
            get { return address; }
            set { address = value; }
        }

        string query,query2;
        Functions function = new Functions();
        Animation animation = new Animation();
        public void viewDoc(DataGridView dataGrid)
        {
            query = "select docID, FirstName, LastName, NIC, DOB, DATEDIFF(YEAR, exp, GETDATE()) as exp, contact, address from Doctor";
            DataTable dTable = new DataTable();
            dTable = function.fillData(query);
            dataGrid.DataSource = dTable;
        }


        public void saveDoc()
        {
            query = "insert into Doctor (FirstName, LastName, NIC, DOB, exp, contact, address) values('"+firstname+ "','" + lastname + "','" + nic + "','" + dob + "','" + exp + "','" + contact + "','" + address + "')";
            query2 = "insert into Users (userName, password,userType) values ('"+txtID.Text+"','password','Doctor')";
            function.ExecuteQuery(query);
            function.ExecuteQuery(query2);
            viewDoc(PublicClass.dataGrid);
            animation.messageBox("Saved Successfully", true);
        }

        public void deleteDoc()
        {
            query = "delete from Doctor where docID="+id+"";
            query2 = "delete from Users where userName='DOC"+id.ToString()+"'";
            function.ExecuteQuery(query);
            function.ExecuteQuery(query2);
            viewDoc(PublicClass.dataGrid);
            animation.messageBox("Deleted Successfully", true);
        }

        public void updateDoc()
        {
            //DateTime date = Convert.ToDateTime(dob);
            query = "update Doctor set FirstName='" + firstname + "', LastName='" + lastname + "', NIC='" + nic + "', DOB='" + dob + "', exp='" + exp + "', contact='" + contact + "', address='" + address + "' where docID="+id+"";
            function.ExecuteQuery(query);
            viewDoc(PublicClass.dataGrid);
            animation.messageBox("Updated Successfully", true);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App.User_Control
{
    public partial class ucAppointment : UserControl
    {
        Functions function = new Functions();
        Animation animation = new Animation();
        Validation validation = new Validation();
        Appointment appointment = new Appointment();
        public ucAppointment()
        {
            InitializeComponent();
            validation.placeHolder(panel);
            validation.numbersOnly(txtID);
        }

        string count;
        string query;
        int docID;
        bool notempty;
        void loadData()
        {
            string date = dtpDate.Text;
            query = "EXEC allDoctors";
            doctorGrid.DataSource = function.fillData(query);
        }

        private void ucAppointment_Load(object sender, EventArgs e)
        {
            dtpDate.Value = DateTime.Today; // Set today date to the Date time Picker
            //dtpDate.MinDate = DateTime.Today;
            loadData();
            pnlDoctor.Location = new Point(0, 0);
        }

        private void dtpDate_ValueChanged(object sender, EventArgs e)
        {
            loadData();
        }

        private void doctorGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //Get appointment count
            docID = Convert.ToInt32(doctorGrid.SelectedRows[0].Cells[0].Value.ToString());
            string query = "SELECT COUNT(docID) as appcount from Appointment where date='" + dtpDate.Text + "' and docID="+ docID + "";
            DataTable dtable = function.fillData(query);
            count = dtable.Rows[0].ItemArray[0].ToString();
            lblAppointment.Text ="Registered Appointments : "+ count;
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            string query;
            if(validation.textBoxEmpty(panel))
            { 
                if(count==8.ToString())
                {
                    animation.messageBox("Appointment Full", false);
                }
                else
                {
                    query = "select patientID from Patient where patientID="+ Convert.ToInt32(txtID.Text)+"";
                    DataTable dtable = function.fillData(query);

                    if(dtable.Rows.Count==0)
                    {
                        animation.messageBox("Patient ID is Incorrect", false);
                    }
                    else
                    {
                        appointment.docID = docID;
                        appointment.patID = Convert.ToInt32(txtID.Text);
                        appointment.Date = dtpDate.Text;
                        appointment.addAppointment();
                        animation.messageBox("Appointment Completed",true);
                    }
                }
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if(validation.textBoxEmpty(panel))
            {
                query = "select patientID from Patient where patientID=" + Convert.ToInt32(txtID.Text) + "";
                DataTable dtable = function.fillData(query);

                if (dtable.Rows.Count == 0)
                {
                    animation.messageBox("Patient ID is Incorrect", false);
                    firstname.Text = "First Name";
                    lastname.Text = "Last Name";
                    nicno.Text = "NIC No";
                    contact.Text = "Contact No";
                    address.Text = "Address";
                }
                else
                {
                    query = "select * from Patient where patientID="+ Convert.ToInt32(txtID.Text) + "";
                    dtable = function.fillData(query);
                    firstname.Text = dtable.Rows[0]["firstName"].ToString();
                    lastname.Text = dtable.Rows[0]["lastName"].ToString();
                    nicno.Text = dtable.Rows[0]["nic"].ToString();
                    contact.Text = dtable.Rows[0]["contactNo"].ToString();
                    address.Text = dtable.Rows[0]["address"].ToString();
                }
            }
        }
    }
}

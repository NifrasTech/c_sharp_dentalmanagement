﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App.User_Control
{
    public partial class ucDoctorMenu : UserControl
    {
        Animation animation = new Animation();
        public ucDoctorMenu()
        {
            InitializeComponent();
        }

        private void btnpatient_Click(object sender, EventArgs e)
        {
            ucPatientEnqry patient = new ucPatientEnqry();
            Animation.pnlContent.Controls.Clear();
            Animation.pnlContent.Controls.Add(patient);
            animation.menuAnimation("Close");
        }

        private void btnAppointment_Click(object sender, EventArgs e)
        {
            ucDoctorDashBoard doctor = new ucDoctorDashBoard();
            Animation.pnlContent.Controls.Clear();
            Animation.pnlContent.Controls.Add(doctor);
            animation.menuAnimation("Close");
        }

        private void btnSetting_Click(object sender, EventArgs e)
        {
            ucChangePassword password = new ucChangePassword();
            Animation.pnlContent.Controls.Clear();
            Animation.pnlContent.Controls.Add(password);
            animation.menuAnimation("Close");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;

namespace Dental_Care___App.User_Control
{
    public partial class ucIncomeReport : UserControl
    {
        Functions function = new Functions();
        Animation animation = new Animation();
        public ucIncomeReport()
        {
            InitializeComponent();
        }

        string query;
        private void ucIncomeReport_Load(object sender, EventArgs e)
        {
            query = "EXEC allDoctors";
            doctorGrid.DataSource = function.fillData(query);

            this.reportViewer1.RefreshReport();
        }

        private void doctorGrid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //string date =DateTime.Now.ToString("yyyy/MM/d");

            string date = dtpDate.Text;

            int docID = Convert.ToInt32(doctorGrid.SelectedRows[0].Cells[0].Value.ToString());
            string docName = doctorGrid.SelectedRows[0].Cells[1].Value.ToString();

            ReportParameterCollection reportPar = new ReportParameterCollection();
            reportPar.Add(new ReportParameter("doctorName", docName));
            this.reportViewer1.LocalReport.SetParameters(reportPar);

            query = "EXEC dailyIncome @day = '"+date+"', @docID = "+docID+"";
            DataTable dtable = new DataTable();
            dtable  = function.fillData(query);

            if(dtable.Rows.Count==0)
            {
                animation.messageBox("Income is Empty "+date+"",false);
            }
            else
            {
                TreatmentBindingSource.DataSource = dtable;
            }

            this.reportViewer1.RefreshReport();
        }
    }
}

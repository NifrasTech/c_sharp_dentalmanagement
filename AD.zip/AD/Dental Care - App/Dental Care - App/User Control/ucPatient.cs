﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App.User_Control
{
    public partial class ucPatient : UserControl
    {
        public ucPatient()
        {
            InitializeComponent();
        }

        Animation anim = new Animation();
        Patient patient = new Patient();
   
        private void btnAdd_Click(object sender, EventArgs e)
        {
            ucPatientForm patienForm = new ucPatientForm();
            Animation.pnlFormLoader.Controls.Clear();
            anim.formAnimation("Open", "Add New Patient");
            Animation.pnlFormLoader.Controls.Add(patienForm);
        }

        private void ucPatient_Load(object sender, EventArgs e)
        {
            PublicClass.dataGrid = patientGrid;
            patient.viewPatient(patientGrid);
        }

        private void patientGrid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

            patient.ID = Convert.ToInt32(patientGrid.SelectedRows[0].Cells[1].Value.ToString());
            patient.FirstName = patientGrid.SelectedRows[0].Cells[2].Value.ToString();
            patient.LastName = patientGrid.SelectedRows[0].Cells[3].Value.ToString();
            patient.NIC = patientGrid.SelectedRows[0].Cells[4].Value.ToString();
            patient.Contact = patientGrid.SelectedRows[0].Cells[5].Value.ToString();
            patient.Address = patientGrid.SelectedRows[0].Cells[6].Value.ToString();

            setValue(); // Set text box value to update form

            ucPatientForm patientForm = new ucPatientForm();
            Animation.pnlFormLoader.Controls.Clear();
            anim.formAnimation("Open", "Edit Patient Details");
            Animation.pnlFormLoader.Controls.Add(patientForm);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            patient.ID = Convert.ToInt32(patientGrid.SelectedRows[0].Cells[1].Value.ToString());
            patient.deletePatient();
        }

        void setValue()
        {
            PublicClass.patID=patient.ID;
            PublicClass.patFirstName = patient.FirstName ;
            PublicClass.patLastName = patient.LastName;
            PublicClass.patNIC = patient.NIC;
            PublicClass.patContact = patient.Contact;
            PublicClass.patAddress = patient.Address;
        }
    }
}

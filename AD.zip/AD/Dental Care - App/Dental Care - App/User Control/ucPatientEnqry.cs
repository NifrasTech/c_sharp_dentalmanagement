﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App.User_Control
{
    public partial class ucPatientEnqry : UserControl
    {
        Validation validation = new Validation();
        Animation animation = new Animation();
        Functions function = new Functions();
        public ucPatientEnqry()
        {
            InitializeComponent();
            validation.placeHolder(pnlTreatment);
            validation.numbersOnly(txtSearch);
        }

        string query;
        DataTable dTabel = new DataTable();
        private void btnSearch_Click(object sender, EventArgs e)
        {
            if(validation.textBoxEmpty(pnlTreatment))
            {
                loadData();
            }

        }

        void loadData()
        {
            int id = Convert.ToInt32(txtSearch.Text);
            query = "select Treatment.name, TreatmentHistory.date from((TreatmentHistory INNER JOIN Treatment on TreatmentHistory.trtmntID = Treatment.trtmntID) INNER JOIN Appointment ON TreatmentHistory.appointID = Appointment.appointID) where Appointment.patID = " + id + " and Appointment.docID=" + User.userID + "";
            dTabel=function.fillData(query);
            if(dTabel.Rows.Count == 0)
            {
                animation.messageBox("The Patient is not available", false);
                animation.messageBox("Patient ID is Incorrect", false);
                firstname.Text = "First Name";
                lastname.Text = "Last Name";
                nicno.Text = "NIC No";
                contact.Text = "Contact No";
                address.Text = "Address";
                treatmentGrid.DataSource = dTabel;
            }
            else
            {
                treatmentGrid.DataSource = dTabel;
                query = "select patientID from Patient where patientID=" + Convert.ToInt32(txtSearch.Text) + "";
                DataTable dtable = function.fillData(query);

                query = "select * from Patient where patientID=" + Convert.ToInt32(txtSearch.Text) + "";
                dtable = function.fillData(query);
                firstname.Text = dtable.Rows[0]["firstName"].ToString();
                lastname.Text = dtable.Rows[0]["lastName"].ToString();
                nicno.Text = dtable.Rows[0]["nic"].ToString();
                contact.Text = dtable.Rows[0]["contactNo"].ToString();
                address.Text = dtable.Rows[0]["address"].ToString();
            }
        }

        //private void cmbType_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    search = cmbType.SelectedItem.ToString();
        //    //MessageBox.Show(search);
        //}

        //private void txtSearch_KeyPress(object sender, KeyPressEventArgs e)
        //{
        //    if(search=="")
        //    {
        //        animation.messageBox("Please select search type from the list", false);
        //    }
        //    else if(search=="Search By Name")
        //    {

        //    }
        //    else if (search == "Search By ID")
        //    {

        //    }
        //    else
        //    {

        //    }
        //}
    }
}

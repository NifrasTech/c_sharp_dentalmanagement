﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App.User_Control
{
    public partial class ucErrorMessage : UserControl
    {
        public ucErrorMessage()
        {
            InitializeComponent();
        }

        private void ucErrorMessage_Load(object sender, EventArgs e)
        {
            lblMessage.Text = Animation.message;
        }
    }
}

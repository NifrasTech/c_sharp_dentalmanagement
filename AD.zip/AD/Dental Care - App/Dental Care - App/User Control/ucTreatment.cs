﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App.User_Control
{
    public partial class ucTreatment : UserControl
    {
        Validation valid = new Validation();
        Treatment treatment = new Treatment();
        public ucTreatment()
        {
            InitializeComponent();
            valid.placeHolder(pnlForm);
            valid.numbersOnly(txtAmount);
        }

        private void ucTreatment_Load(object sender, EventArgs e)
        {
            PublicClass.dataGrid = treatmentGrid;
            treatment.viewTreatment(treatmentGrid);
            btnAdd.Visible = true;
            btnUpdate.Visible = false;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if(valid.textBoxEmpty(pnlForm))
            {
                treatment.Name = txtName.Text;
                treatment.Amount = Convert.ToDecimal(txtAmount.Text);
                treatment.saveTreatment();
                valid.clearAllTextBox(pnlForm);
            }

        }

        private void treatmentGrid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            btnAdd.Visible = false;
            btnUpdate.Visible = true;

            treatment.ID = Convert.ToInt32(treatmentGrid.SelectedRows[0].Cells[0].Value.ToString());
            treatment.Name = treatmentGrid.SelectedRows[0].Cells[1].Value.ToString();
            treatment.Amount = Convert.ToDecimal(treatmentGrid.SelectedRows[0].Cells[2].Value.ToString());

            valid.setTextBoxColor(pnlForm);
            txtName.Text = treatment.Name;
            txtAmount.Text = treatment.Amount.ToString();

        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            valid.clearAllTextBox(pnlForm);
            btnAdd.Visible = true;
            btnUpdate.Visible = false;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if(valid.textBoxEmpty(pnlForm))
            {
                treatment.Name = txtName.Text;
                treatment.Amount = Convert.ToDecimal(txtAmount.Text);
                treatment.updateTreatment();
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            treatment.ID = Convert.ToInt32(treatmentGrid.SelectedRows[0].Cells[0].Value.ToString());
            treatment.deleteTreatment();
        }
    }
}

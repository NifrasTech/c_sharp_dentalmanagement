﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App.User_Control
{
    public partial class ucAdmin : UserControl
    {
        public ucAdmin()
        {
            InitializeComponent();
        }

        private void btnClickHere_Click(object sender, EventArgs e)
        {
            Animation anim = new Animation();
            ucAdminMenu admin = new ucAdminMenu();
            Animation.pnlMenu.Controls.Clear();
            Animation.pnlMenu.Controls.Add(admin);
            anim.menuAnimation("Open");
        }
    }
}

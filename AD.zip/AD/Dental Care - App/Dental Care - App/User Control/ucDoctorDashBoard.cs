﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App.User_Control
{
    public partial class ucDoctorDashBoard : UserControl
    {
        Functions function = new Functions();
        Animation animation = new Animation();
        Treatment treatment = new Treatment();
        TreatmentHistory treatmentHistory = new TreatmentHistory();
        Appointment appointment = new Appointment();
        public ucDoctorDashBoard()
        {
            InitializeComponent();
        }

        //void rowCount()
        //{
        //    string count = patientGrid.RowCount.ToString();
        //    lblCount.Text = count + " Appointments";
        //}

        int patientID;
        int appointID;
        string fullName;

        private void btnAll_Click(object sender, EventArgs e)
        {
            appointment.viewAppointment(patientGrid);
        }

        private void ucDoctorDashBoard_Load(object sender, EventArgs e)
        {
            dtpDate.Value = DateTime.Today;
            appointment.Date = dtpDate.Text;
            appointment.viewAppointmentbyDate(patientGrid);
            //rowCount();
            pnlAppointment.Location = new Point(0, 0);
            pnlTreatment.Top = this.Height;
        }

        private void dtpDate_ValueChanged(object sender, EventArgs e) //List all appoinment by date change
        {
            appointment.Date = dtpDate.Text;
            appointment.viewAppointmentbyDate(patientGrid);
        }

        private void patientGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            appointID = Convert.ToInt32(patientGrid.SelectedRows[0].Cells[0].Value.ToString());
            patientID = Convert.ToInt32(patientGrid.SelectedRows[0].Cells[1].Value.ToString());
            fullName = patientGrid.SelectedRows[0].Cells[2].Value.ToString();
            lblDetails.Text = "Appointment ID   : " + appointID.ToString() + "\n\nPatient ID              :  " + patientID.ToString() + "\n\nPatient Name       : " + fullName;
            treatment.viewTreatment(treatmentGrid);
            animation.changePanel(pnlAppointment, pnlTreatment,true);//Open Treatment Panel
        }

        private void btnAppoinment_Click(object sender, EventArgs e)
        {
            animation.changePanel(pnlAppointment, pnlTreatment, false); // Close treatment panel
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            int trtmntID = Convert.ToInt32(treatmentGrid.SelectedRows[0].Cells[0].Value.ToString());
            treatmentHistory.appointID = appointID;
            treatmentHistory.trtmntID = trtmntID;
            treatmentHistory.Date = DateTime.Today.ToString("yyyy/MM/dd");

            treatmentHistory.saveTreatmentHistory();
        }
    }
}

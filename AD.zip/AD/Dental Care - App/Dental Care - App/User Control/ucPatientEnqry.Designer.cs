﻿namespace Dental_Care___App.User_Control
{
    partial class ucPatientEnqry
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucPatientEnqry));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.pnlTreatment = new System.Windows.Forms.Panel();
            this.btnSearch = new Bunifu.Framework.UI.BunifuFlatButton();
            this.treatmentGrid = new System.Windows.Forms.DataGridView();
            this.trtmntName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.address = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.contact = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lastname = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.nicno = new System.Windows.Forms.Label();
            this.firstname = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnlTreatment.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.treatmentGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // txtSearch
            // 
            this.txtSearch.BackColor = System.Drawing.Color.White;
            this.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSearch.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearch.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.txtSearch.Location = new System.Drawing.Point(154, 139);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(185, 26);
            this.txtSearch.TabIndex = 59;
            this.txtSearch.Tag = "Search Here...";
            this.txtSearch.Text = "Search Here...";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel10.Location = new System.Drawing.Point(153, 171);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(186, 1);
            this.panel10.TabIndex = 60;
            // 
            // pnlTreatment
            // 
            this.pnlTreatment.Controls.Add(this.address);
            this.pnlTreatment.Controls.Add(this.label7);
            this.pnlTreatment.Controls.Add(this.contact);
            this.pnlTreatment.Controls.Add(this.label5);
            this.pnlTreatment.Controls.Add(this.lastname);
            this.pnlTreatment.Controls.Add(this.label3);
            this.pnlTreatment.Controls.Add(this.nicno);
            this.pnlTreatment.Controls.Add(this.firstname);
            this.pnlTreatment.Controls.Add(this.label4);
            this.pnlTreatment.Controls.Add(this.label6);
            this.pnlTreatment.Controls.Add(this.panel5);
            this.pnlTreatment.Controls.Add(this.panel4);
            this.pnlTreatment.Controls.Add(this.panel3);
            this.pnlTreatment.Controls.Add(this.panel2);
            this.pnlTreatment.Controls.Add(this.panel1);
            this.pnlTreatment.Controls.Add(this.btnSearch);
            this.pnlTreatment.Controls.Add(this.treatmentGrid);
            this.pnlTreatment.Controls.Add(this.txtSearch);
            this.pnlTreatment.Controls.Add(this.panel10);
            this.pnlTreatment.Controls.Add(this.bunifuCustomLabel1);
            this.pnlTreatment.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTreatment.Location = new System.Drawing.Point(0, 0);
            this.pnlTreatment.Name = "pnlTreatment";
            this.pnlTreatment.Size = new System.Drawing.Size(900, 650);
            this.pnlTreatment.TabIndex = 61;
            // 
            // btnSearch
            // 
            this.btnSearch.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSearch.BorderRadius = 7;
            this.btnSearch.ButtonText = "";
            this.btnSearch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSearch.DisabledColor = System.Drawing.Color.Gray;
            this.btnSearch.Iconcolor = System.Drawing.Color.Transparent;
            this.btnSearch.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnSearch.Iconimage")));
            this.btnSearch.Iconimage_right = null;
            this.btnSearch.Iconimage_right_Selected = null;
            this.btnSearch.Iconimage_Selected = null;
            this.btnSearch.IconMarginLeft = 0;
            this.btnSearch.IconMarginRight = 0;
            this.btnSearch.IconRightVisible = true;
            this.btnSearch.IconRightZoom = 0D;
            this.btnSearch.IconVisible = true;
            this.btnSearch.IconZoom = 50D;
            this.btnSearch.IsTab = false;
            this.btnSearch.Location = new System.Drawing.Point(345, 133);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnSearch.OnHovercolor = System.Drawing.SystemColors.MenuHighlight;
            this.btnSearch.OnHoverTextColor = System.Drawing.Color.White;
            this.btnSearch.selected = false;
            this.btnSearch.Size = new System.Drawing.Size(40, 39);
            this.btnSearch.TabIndex = 66;
            this.btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSearch.Textcolor = System.Drawing.Color.White;
            this.btnSearch.TextFont = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // treatmentGrid
            // 
            this.treatmentGrid.AllowUserToAddRows = false;
            this.treatmentGrid.AllowUserToDeleteRows = false;
            this.treatmentGrid.AllowUserToResizeColumns = false;
            this.treatmentGrid.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(34)))), ((int)(((byte)(37)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White;
            this.treatmentGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.treatmentGrid.BackgroundColor = System.Drawing.Color.White;
            this.treatmentGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.treatmentGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.treatmentGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(34)))), ((int)(((byte)(37)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.treatmentGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.treatmentGrid.ColumnHeadersHeight = 30;
            this.treatmentGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.treatmentGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.trtmntName,
            this.Column1});
            this.treatmentGrid.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.HotTrack;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.treatmentGrid.DefaultCellStyle = dataGridViewCellStyle4;
            this.treatmentGrid.EnableHeadersVisualStyles = false;
            this.treatmentGrid.GridColor = System.Drawing.Color.White;
            this.treatmentGrid.Location = new System.Drawing.Point(506, 133);
            this.treatmentGrid.MultiSelect = false;
            this.treatmentGrid.Name = "treatmentGrid";
            this.treatmentGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.treatmentGrid.RowHeadersVisible = false;
            this.treatmentGrid.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White;
            this.treatmentGrid.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.treatmentGrid.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(34)))), ((int)(((byte)(37)))));
            this.treatmentGrid.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.HotTrack;
            this.treatmentGrid.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.White;
            this.treatmentGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.treatmentGrid.ShowCellToolTips = false;
            this.treatmentGrid.Size = new System.Drawing.Size(352, 329);
            this.treatmentGrid.TabIndex = 64;
            this.treatmentGrid.TabStop = false;
            // 
            // trtmntName
            // 
            this.trtmntName.DataPropertyName = "name";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomLeft;
            this.trtmntName.DefaultCellStyle = dataGridViewCellStyle3;
            this.trtmntName.HeaderText = "Treatment";
            this.trtmntName.Name = "trtmntName";
            this.trtmntName.Width = 200;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "date";
            this.Column1.HeaderText = "Treatment Date";
            this.Column1.Name = "Column1";
            this.Column1.Width = 150;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(36, 136);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(123, 34);
            this.bunifuCustomLabel1.TabIndex = 65;
            this.bunifuCustomLabel1.Text = "Search by ID :";
            this.bunifuCustomLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // address
            // 
            this.address.BackColor = System.Drawing.Color.Transparent;
            this.address.Font = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.address.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.address.Location = new System.Drawing.Point(158, 421);
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(120, 37);
            this.address.TabIndex = 81;
            this.address.Text = "Address ";
            this.address.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(51, 421);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 37);
            this.label7.TabIndex = 82;
            this.label7.Text = "Address : ";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // contact
            // 
            this.contact.BackColor = System.Drawing.Color.Transparent;
            this.contact.Font = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contact.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.contact.Location = new System.Drawing.Point(158, 365);
            this.contact.Name = "contact";
            this.contact.Size = new System.Drawing.Size(118, 37);
            this.contact.TabIndex = 83;
            this.contact.Text = "Contact No ";
            this.contact.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(25, 365);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(118, 37);
            this.label5.TabIndex = 84;
            this.label5.Text = "Contact No : ";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lastname
            // 
            this.lastname.BackColor = System.Drawing.Color.Transparent;
            this.lastname.Font = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastname.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lastname.Location = new System.Drawing.Point(158, 248);
            this.lastname.Name = "lastname";
            this.lastname.Size = new System.Drawing.Size(122, 37);
            this.lastname.TabIndex = 85;
            this.lastname.Text = "Last Name ";
            this.lastname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(32, 248);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(122, 37);
            this.label3.TabIndex = 86;
            this.label3.Text = "Last Name : ";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nicno
            // 
            this.nicno.BackColor = System.Drawing.Color.Transparent;
            this.nicno.Font = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nicno.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.nicno.Location = new System.Drawing.Point(158, 309);
            this.nicno.Name = "nicno";
            this.nicno.Size = new System.Drawing.Size(107, 37);
            this.nicno.TabIndex = 87;
            this.nicno.Text = "NIC No ";
            this.nicno.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // firstname
            // 
            this.firstname.BackColor = System.Drawing.Color.Transparent;
            this.firstname.Font = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstname.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.firstname.Location = new System.Drawing.Point(158, 188);
            this.firstname.Name = "firstname";
            this.firstname.Size = new System.Drawing.Size(122, 37);
            this.firstname.TabIndex = 89;
            this.firstname.Text = "First Name ";
            this.firstname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(64, 309);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 37);
            this.label4.TabIndex = 88;
            this.label4.Text = "NIC No : ";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(32, 188);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(122, 37);
            this.label6.TabIndex = 90;
            this.label6.Text = "First Name : ";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel5.Location = new System.Drawing.Point(160, 461);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(250, 1);
            this.panel5.TabIndex = 76;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel4.Location = new System.Drawing.Point(162, 405);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(250, 1);
            this.panel4.TabIndex = 77;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel3.Location = new System.Drawing.Point(162, 349);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(250, 1);
            this.panel3.TabIndex = 78;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel2.Location = new System.Drawing.Point(160, 288);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(250, 1);
            this.panel2.TabIndex = 79;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel1.Location = new System.Drawing.Point(160, 228);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(250, 1);
            this.panel1.TabIndex = 80;
            // 
            // ucPatientEnqry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.pnlTreatment);
            this.Name = "ucPatientEnqry";
            this.Size = new System.Drawing.Size(900, 650);
            this.pnlTreatment.ResumeLayout(false);
            this.pnlTreatment.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.treatmentGrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel pnlTreatment;
        private System.Windows.Forms.DataGridView treatmentGrid;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuFlatButton btnSearch;
        private System.Windows.Forms.DataGridViewTextBoxColumn trtmntName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.Label address;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label contact;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lastname;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label nicno;
        private System.Windows.Forms.Label firstname;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
    }
}

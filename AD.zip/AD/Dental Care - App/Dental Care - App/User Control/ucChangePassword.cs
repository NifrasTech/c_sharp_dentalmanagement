﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App.User_Control
{
    public partial class ucChangePassword : UserControl
    {
        Validation validation = new Validation();
        Animation animation = new Animation();
        Functions function = new Functions();
        public ucChangePassword()
        {
            InitializeComponent();
            validation.placeHolder(pnlForm);
        }

        bool password=false;
        private void ucChangePassword_Load(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if(User.password==txtOld.Text && password==true)
            {
                string query = "update Users set password='"+txtConfirm.Text+"' where userName='"+User.userName+"'";
                function.ExecuteQuery(query);
                animation.messageBox("Your Password has been changed",true);
                validation.clearAllTextBox(pnlForm);
            }
            else
            {
                animation.messageBox("Please correct your password", false);
            }
        }

        private void txtOld_TextChanged(object sender, EventArgs e)
        {
            if(User.password==txtOld.Text)
            {
                txtOld.ForeColor = Color.Green;
            }
            else
            {
                txtOld.ForeColor = Color.Red;
                password = false;
            }
        }

        private void txtNew_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtConfirm_TextChanged(object sender, EventArgs e)
        {
            if (txtNew.Text == txtConfirm.Text)
            {
                txtConfirm.ForeColor = Color.Green;
                password = true;
            }
            else
            {
                txtConfirm.ForeColor = Color.Red;
                password = false;
            }
        }
    }
}

﻿namespace Dental_Care___App.User_Control
{
    partial class ucDoctor
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucDoctor));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnDelete = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnAdd = new Bunifu.Framework.UI.BunifuFlatButton();
            this.doctorGrid = new System.Windows.Forms.DataGridView();
            this.docID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.docFirstName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.docLastname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.docNIC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.docDOB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.docExp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.docContact = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.docAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnPrint = new Bunifu.Framework.UI.BunifuFlatButton();
            ((System.ComponentModel.ISupportInitialize)(this.doctorGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // btnDelete
            // 
            this.btnDelete.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnDelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDelete.BorderRadius = 7;
            this.btnDelete.ButtonText = "Delete";
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.DisabledColor = System.Drawing.Color.Gray;
            this.btnDelete.Iconcolor = System.Drawing.Color.Transparent;
            this.btnDelete.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnDelete.Iconimage")));
            this.btnDelete.Iconimage_right = null;
            this.btnDelete.Iconimage_right_Selected = null;
            this.btnDelete.Iconimage_Selected = null;
            this.btnDelete.IconMarginLeft = 0;
            this.btnDelete.IconMarginRight = 0;
            this.btnDelete.IconRightVisible = true;
            this.btnDelete.IconRightZoom = 0D;
            this.btnDelete.IconVisible = true;
            this.btnDelete.IconZoom = 75D;
            this.btnDelete.IsTab = false;
            this.btnDelete.Location = new System.Drawing.Point(191, 88);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnDelete.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnDelete.OnHoverTextColor = System.Drawing.Color.White;
            this.btnDelete.selected = false;
            this.btnDelete.Size = new System.Drawing.Size(169, 48);
            this.btnDelete.TabIndex = 48;
            this.btnDelete.Text = "Delete";
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDelete.Textcolor = System.Drawing.Color.White;
            this.btnDelete.TextFont = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAdd.BorderRadius = 7;
            this.btnAdd.ButtonText = "Add New";
            this.btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdd.DisabledColor = System.Drawing.Color.Gray;
            this.btnAdd.Iconcolor = System.Drawing.Color.Transparent;
            this.btnAdd.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnAdd.Iconimage")));
            this.btnAdd.Iconimage_right = null;
            this.btnAdd.Iconimage_right_Selected = null;
            this.btnAdd.Iconimage_Selected = null;
            this.btnAdd.IconMarginLeft = 0;
            this.btnAdd.IconMarginRight = 0;
            this.btnAdd.IconRightVisible = true;
            this.btnAdd.IconRightZoom = 0D;
            this.btnAdd.IconVisible = true;
            this.btnAdd.IconZoom = 80D;
            this.btnAdd.IsTab = false;
            this.btnAdd.Location = new System.Drawing.Point(16, 88);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnAdd.OnHovercolor = System.Drawing.Color.SeaGreen;
            this.btnAdd.OnHoverTextColor = System.Drawing.Color.White;
            this.btnAdd.selected = false;
            this.btnAdd.Size = new System.Drawing.Size(169, 48);
            this.btnAdd.TabIndex = 49;
            this.btnAdd.Text = "Add New";
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAdd.Textcolor = System.Drawing.Color.White;
            this.btnAdd.TextFont = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // doctorGrid
            // 
            this.doctorGrid.AllowUserToAddRows = false;
            this.doctorGrid.AllowUserToDeleteRows = false;
            this.doctorGrid.AllowUserToResizeColumns = false;
            this.doctorGrid.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(34)))), ((int)(((byte)(37)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White;
            this.doctorGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.doctorGrid.BackgroundColor = System.Drawing.Color.White;
            this.doctorGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.doctorGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.doctorGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(34)))), ((int)(((byte)(37)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.doctorGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.doctorGrid.ColumnHeadersHeight = 30;
            this.doctorGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.doctorGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.docID,
            this.docFirstName,
            this.docLastname,
            this.docNIC,
            this.docDOB,
            this.docExp,
            this.docContact,
            this.docAddress});
            this.doctorGrid.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.HotTrack;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.doctorGrid.DefaultCellStyle = dataGridViewCellStyle3;
            this.doctorGrid.EnableHeadersVisualStyles = false;
            this.doctorGrid.GridColor = System.Drawing.Color.White;
            this.doctorGrid.Location = new System.Drawing.Point(6, 143);
            this.doctorGrid.MultiSelect = false;
            this.doctorGrid.Name = "doctorGrid";
            this.doctorGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.doctorGrid.RowHeadersVisible = false;
            this.doctorGrid.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White;
            this.doctorGrid.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.doctorGrid.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(34)))), ((int)(((byte)(37)))));
            this.doctorGrid.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.HotTrack;
            this.doctorGrid.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.White;
            this.doctorGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.doctorGrid.ShowCellToolTips = false;
            this.doctorGrid.Size = new System.Drawing.Size(895, 420);
            this.doctorGrid.TabIndex = 47;
            this.doctorGrid.TabStop = false;
            this.doctorGrid.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.doctorGrid_CellDoubleClick);
            // 
            // docID
            // 
            this.docID.DataPropertyName = "docID";
            this.docID.HeaderText = "ID";
            this.docID.Name = "docID";
            this.docID.Width = 30;
            // 
            // docFirstName
            // 
            this.docFirstName.DataPropertyName = "FirstName";
            this.docFirstName.HeaderText = "First Name";
            this.docFirstName.Name = "docFirstName";
            this.docFirstName.Width = 130;
            // 
            // docLastname
            // 
            this.docLastname.DataPropertyName = "LastName";
            this.docLastname.HeaderText = "Last Name";
            this.docLastname.Name = "docLastname";
            this.docLastname.Width = 130;
            // 
            // docNIC
            // 
            this.docNIC.DataPropertyName = "NIC";
            this.docNIC.HeaderText = "NIC No";
            this.docNIC.Name = "docNIC";
            this.docNIC.Width = 120;
            // 
            // docDOB
            // 
            this.docDOB.DataPropertyName = "DOB";
            this.docDOB.HeaderText = "DOB";
            this.docDOB.Name = "docDOB";
            // 
            // docExp
            // 
            this.docExp.DataPropertyName = "exp";
            this.docExp.HeaderText = "Exp";
            this.docExp.Name = "docExp";
            this.docExp.Width = 50;
            // 
            // docContact
            // 
            this.docContact.DataPropertyName = "contact";
            this.docContact.HeaderText = "Contact";
            this.docContact.Name = "docContact";
            this.docContact.Width = 130;
            // 
            // docAddress
            // 
            this.docAddress.DataPropertyName = "address";
            this.docAddress.HeaderText = "Address";
            this.docAddress.Name = "docAddress";
            this.docAddress.Width = 200;
            // 
            // btnPrint
            // 
            this.btnPrint.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnPrint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnPrint.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPrint.BorderRadius = 7;
            this.btnPrint.ButtonText = "Sort By Experience";
            this.btnPrint.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPrint.DisabledColor = System.Drawing.Color.Gray;
            this.btnPrint.Iconcolor = System.Drawing.Color.Transparent;
            this.btnPrint.Iconimage = null;
            this.btnPrint.Iconimage_right = null;
            this.btnPrint.Iconimage_right_Selected = null;
            this.btnPrint.Iconimage_Selected = null;
            this.btnPrint.IconMarginLeft = 0;
            this.btnPrint.IconMarginRight = 0;
            this.btnPrint.IconRightVisible = true;
            this.btnPrint.IconRightZoom = 0D;
            this.btnPrint.IconVisible = true;
            this.btnPrint.IconZoom = 75D;
            this.btnPrint.IsTab = false;
            this.btnPrint.Location = new System.Drawing.Point(366, 88);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnPrint.OnHovercolor = System.Drawing.SystemColors.HotTrack;
            this.btnPrint.OnHoverTextColor = System.Drawing.Color.White;
            this.btnPrint.selected = false;
            this.btnPrint.Size = new System.Drawing.Size(185, 48);
            this.btnPrint.TabIndex = 78;
            this.btnPrint.Text = "Sort By Experience";
            this.btnPrint.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnPrint.Textcolor = System.Drawing.Color.White;
            this.btnPrint.TextFont = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // ucDoctor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.doctorGrid);
            this.Name = "ucDoctor";
            this.Size = new System.Drawing.Size(900, 650);
            this.Load += new System.EventHandler(this.ucDoctor_Load);
            ((System.ComponentModel.ISupportInitialize)(this.doctorGrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Bunifu.Framework.UI.BunifuFlatButton btnDelete;
        private Bunifu.Framework.UI.BunifuFlatButton btnAdd;
        private System.Windows.Forms.DataGridView doctorGrid;
        private System.Windows.Forms.DataGridViewTextBoxColumn docID;
        private System.Windows.Forms.DataGridViewTextBoxColumn docFirstName;
        private System.Windows.Forms.DataGridViewTextBoxColumn docLastname;
        private System.Windows.Forms.DataGridViewTextBoxColumn docNIC;
        private System.Windows.Forms.DataGridViewTextBoxColumn docDOB;
        private System.Windows.Forms.DataGridViewTextBoxColumn docExp;
        private System.Windows.Forms.DataGridViewTextBoxColumn docContact;
        private System.Windows.Forms.DataGridViewTextBoxColumn docAddress;
        private Bunifu.Framework.UI.BunifuFlatButton btnPrint;
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App.User_Control
{
    public partial class ucOfficerDashBoard : UserControl
    {
        public ucOfficerDashBoard()
        {
            InitializeComponent();
        }

        private void btnClickHere_Click(object sender, EventArgs e)
        {
            Animation anim = new Animation();
            ucFrontOfficerMenu ucFrontOfficer = new ucFrontOfficerMenu();
            Animation.pnlMenu.Controls.Clear();
            Animation.pnlMenu.Controls.Add(ucFrontOfficer);
            anim.menuAnimation("Open");
        }
    }
}

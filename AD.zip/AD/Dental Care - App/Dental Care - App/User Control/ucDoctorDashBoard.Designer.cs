﻿namespace Dental_Care___App.User_Control
{
    partial class ucDoctorDashBoard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucDoctorDashBoard));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlAppointment = new System.Windows.Forms.Panel();
            this.btnAll = new Bunifu.Framework.UI.BunifuFlatButton();
            this.lblCount = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            this.patientGrid = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.patID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fullname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.patContact = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AppointmentDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlTreatment = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.lblDetails = new System.Windows.Forms.Label();
            this.btnAddNew = new System.Windows.Forms.Button();
            this.treatmentGrid = new System.Windows.Forms.DataGridView();
            this.btnAppoinment = new Bunifu.Framework.UI.BunifuFlatButton();
            this.docID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.trtmntName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.docNIC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlAppointment.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.patientGrid)).BeginInit();
            this.pnlTreatment.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.treatmentGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlAppointment
            // 
            this.pnlAppointment.Controls.Add(this.btnAll);
            this.pnlAppointment.Controls.Add(this.lblCount);
            this.pnlAppointment.Controls.Add(this.label1);
            this.pnlAppointment.Controls.Add(this.dtpDate);
            this.pnlAppointment.Controls.Add(this.patientGrid);
            this.pnlAppointment.Location = new System.Drawing.Point(0, 0);
            this.pnlAppointment.Name = "pnlAppointment";
            this.pnlAppointment.Size = new System.Drawing.Size(900, 650);
            this.pnlAppointment.TabIndex = 57;
            // 
            // btnAll
            // 
            this.btnAll.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnAll.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAll.BorderRadius = 7;
            this.btnAll.ButtonText = "All Appoinment";
            this.btnAll.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAll.DisabledColor = System.Drawing.Color.Gray;
            this.btnAll.Iconcolor = System.Drawing.Color.Transparent;
            this.btnAll.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnAll.Iconimage")));
            this.btnAll.Iconimage_right = null;
            this.btnAll.Iconimage_right_Selected = null;
            this.btnAll.Iconimage_Selected = null;
            this.btnAll.IconMarginLeft = 0;
            this.btnAll.IconMarginRight = 0;
            this.btnAll.IconRightVisible = true;
            this.btnAll.IconRightZoom = 0D;
            this.btnAll.IconVisible = true;
            this.btnAll.IconZoom = 75D;
            this.btnAll.IsTab = false;
            this.btnAll.Location = new System.Drawing.Point(66, 97);
            this.btnAll.Name = "btnAll";
            this.btnAll.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnAll.OnHovercolor = System.Drawing.Color.RoyalBlue;
            this.btnAll.OnHoverTextColor = System.Drawing.Color.White;
            this.btnAll.selected = false;
            this.btnAll.Size = new System.Drawing.Size(178, 40);
            this.btnAll.TabIndex = 60;
            this.btnAll.Text = "All Appoinment";
            this.btnAll.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAll.Textcolor = System.Drawing.Color.White;
            this.btnAll.TextFont = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAll.Click += new System.EventHandler(this.btnAll_Click);
            // 
            // lblCount
            // 
            this.lblCount.BackColor = System.Drawing.Color.Transparent;
            this.lblCount.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCount.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblCount.Location = new System.Drawing.Point(250, 101);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(175, 34);
            this.lblCount.TabIndex = 59;
            this.lblCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(420, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(271, 34);
            this.label1.TabIndex = 59;
            this.label1.Text = "View Appointment By Date : ";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dtpDate
            // 
            this.dtpDate.CalendarFont = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDate.CalendarForeColor = System.Drawing.Color.White;
            this.dtpDate.CalendarMonthBackground = System.Drawing.SystemColors.MenuHighlight;
            this.dtpDate.CalendarTitleBackColor = System.Drawing.SystemColors.MenuHighlight;
            this.dtpDate.CalendarTitleForeColor = System.Drawing.Color.White;
            this.dtpDate.CalendarTrailingForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.dtpDate.CustomFormat = "yyyy/MM/dd";
            this.dtpDate.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.dtpDate.Font = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDate.Location = new System.Drawing.Point(691, 101);
            this.dtpDate.MaxDate = new System.DateTime(3000, 12, 31, 0, 0, 0, 0);
            this.dtpDate.MinDate = new System.DateTime(1800, 1, 1, 0, 0, 0, 0);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dtpDate.Size = new System.Drawing.Size(133, 32);
            this.dtpDate.TabIndex = 58;
            this.dtpDate.Value = new System.DateTime(2019, 8, 13, 0, 0, 0, 0);
            this.dtpDate.ValueChanged += new System.EventHandler(this.dtpDate_ValueChanged);
            // 
            // patientGrid
            // 
            this.patientGrid.AllowUserToAddRows = false;
            this.patientGrid.AllowUserToDeleteRows = false;
            this.patientGrid.AllowUserToResizeColumns = false;
            this.patientGrid.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(34)))), ((int)(((byte)(37)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White;
            this.patientGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.patientGrid.BackgroundColor = System.Drawing.Color.White;
            this.patientGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.patientGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.patientGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(34)))), ((int)(((byte)(37)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.patientGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.patientGrid.ColumnHeadersHeight = 30;
            this.patientGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.patientGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.patID,
            this.fullname,
            this.patContact,
            this.AppointmentDate,
            this.status});
            this.patientGrid.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.HotTrack;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.patientGrid.DefaultCellStyle = dataGridViewCellStyle3;
            this.patientGrid.EnableHeadersVisualStyles = false;
            this.patientGrid.GridColor = System.Drawing.Color.White;
            this.patientGrid.Location = new System.Drawing.Point(66, 140);
            this.patientGrid.MultiSelect = false;
            this.patientGrid.Name = "patientGrid";
            this.patientGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.patientGrid.RowHeadersVisible = false;
            this.patientGrid.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White;
            this.patientGrid.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patientGrid.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(34)))), ((int)(((byte)(37)))));
            this.patientGrid.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.HotTrack;
            this.patientGrid.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.White;
            this.patientGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.patientGrid.ShowCellToolTips = false;
            this.patientGrid.Size = new System.Drawing.Size(764, 493);
            this.patientGrid.TabIndex = 57;
            this.patientGrid.TabStop = false;
            this.patientGrid.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.patientGrid_CellContentClick);
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "appointID";
            this.Column1.HeaderText = "Appoint ID";
            this.Column1.Name = "Column1";
            // 
            // patID
            // 
            this.patID.DataPropertyName = "patientID";
            this.patID.HeaderText = "ID";
            this.patID.Name = "patID";
            this.patID.Width = 50;
            // 
            // fullname
            // 
            this.fullname.DataPropertyName = "fullname";
            this.fullname.HeaderText = "Full Name";
            this.fullname.Name = "fullname";
            this.fullname.Width = 180;
            // 
            // patContact
            // 
            this.patContact.DataPropertyName = "contactNo";
            this.patContact.HeaderText = "Contact";
            this.patContact.Name = "patContact";
            this.patContact.Width = 150;
            // 
            // AppointmentDate
            // 
            this.AppointmentDate.DataPropertyName = "date";
            this.AppointmentDate.HeaderText = "Date";
            this.AppointmentDate.Name = "AppointmentDate";
            this.AppointmentDate.Width = 130;
            // 
            // status
            // 
            this.status.DataPropertyName = "status";
            this.status.HeaderText = "Status";
            this.status.Name = "status";
            this.status.Width = 150;
            // 
            // pnlTreatment
            // 
            this.pnlTreatment.Controls.Add(this.label2);
            this.pnlTreatment.Controls.Add(this.lblDetails);
            this.pnlTreatment.Controls.Add(this.btnAddNew);
            this.pnlTreatment.Controls.Add(this.treatmentGrid);
            this.pnlTreatment.Controls.Add(this.btnAppoinment);
            this.pnlTreatment.Location = new System.Drawing.Point(0, 0);
            this.pnlTreatment.Name = "pnlTreatment";
            this.pnlTreatment.Size = new System.Drawing.Size(900, 650);
            this.pnlTreatment.TabIndex = 58;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label2.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(259, 529);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(391, 27);
            this.label2.TabIndex = 65;
            this.label2.Text = "Select Treatment for the patient from this table";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDetails
            // 
            this.lblDetails.BackColor = System.Drawing.Color.Transparent;
            this.lblDetails.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDetails.ForeColor = System.Drawing.Color.Black;
            this.lblDetails.Location = new System.Drawing.Point(258, 75);
            this.lblDetails.Name = "lblDetails";
            this.lblDetails.Size = new System.Drawing.Size(385, 123);
            this.lblDetails.TabIndex = 65;
            this.lblDetails.Text = "Patient ID              : \r\n\r\nAppointment ID   :\r\n\r\nPatient Name       :";
            // 
            // btnAddNew
            // 
            this.btnAddNew.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(34)))), ((int)(((byte)(37)))));
            this.btnAddNew.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAddNew.BackgroundImage")));
            this.btnAddNew.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnAddNew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddNew.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control;
            this.btnAddNew.FlatAppearance.BorderSize = 0;
            this.btnAddNew.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGreen;
            this.btnAddNew.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnAddNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddNew.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNew.ForeColor = System.Drawing.Color.White;
            this.btnAddNew.Location = new System.Drawing.Point(260, 203);
            this.btnAddNew.Name = "btnAddNew";
            this.btnAddNew.Size = new System.Drawing.Size(390, 33);
            this.btnAddNew.TabIndex = 64;
            this.btnAddNew.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAddNew.UseVisualStyleBackColor = false;
            this.btnAddNew.Click += new System.EventHandler(this.btnAddNew_Click);
            // 
            // treatmentGrid
            // 
            this.treatmentGrid.AllowUserToAddRows = false;
            this.treatmentGrid.AllowUserToDeleteRows = false;
            this.treatmentGrid.AllowUserToResizeColumns = false;
            this.treatmentGrid.AllowUserToResizeRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(34)))), ((int)(((byte)(37)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.White;
            this.treatmentGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.treatmentGrid.BackgroundColor = System.Drawing.Color.White;
            this.treatmentGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.treatmentGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.treatmentGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(34)))), ((int)(((byte)(37)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.treatmentGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.treatmentGrid.ColumnHeadersHeight = 30;
            this.treatmentGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.treatmentGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.docID,
            this.trtmntName,
            this.docNIC});
            this.treatmentGrid.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.HotTrack;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.treatmentGrid.DefaultCellStyle = dataGridViewCellStyle7;
            this.treatmentGrid.EnableHeadersVisualStyles = false;
            this.treatmentGrid.GridColor = System.Drawing.Color.White;
            this.treatmentGrid.Location = new System.Drawing.Point(259, 242);
            this.treatmentGrid.MultiSelect = false;
            this.treatmentGrid.Name = "treatmentGrid";
            this.treatmentGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.treatmentGrid.RowHeadersVisible = false;
            this.treatmentGrid.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White;
            this.treatmentGrid.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.treatmentGrid.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(34)))), ((int)(((byte)(37)))));
            this.treatmentGrid.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.HotTrack;
            this.treatmentGrid.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.White;
            this.treatmentGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.treatmentGrid.ShowCellToolTips = false;
            this.treatmentGrid.Size = new System.Drawing.Size(391, 284);
            this.treatmentGrid.TabIndex = 63;
            this.treatmentGrid.TabStop = false;
            // 
            // btnAppoinment
            // 
            this.btnAppoinment.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnAppoinment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnAppoinment.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAppoinment.BorderRadius = 7;
            this.btnAppoinment.ButtonText = "Go to Appointment";
            this.btnAppoinment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAppoinment.DisabledColor = System.Drawing.Color.Gray;
            this.btnAppoinment.Iconcolor = System.Drawing.Color.Transparent;
            this.btnAppoinment.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnAppoinment.Iconimage")));
            this.btnAppoinment.Iconimage_right = null;
            this.btnAppoinment.Iconimage_right_Selected = null;
            this.btnAppoinment.Iconimage_Selected = null;
            this.btnAppoinment.IconMarginLeft = 0;
            this.btnAppoinment.IconMarginRight = 0;
            this.btnAppoinment.IconRightVisible = true;
            this.btnAppoinment.IconRightZoom = 0D;
            this.btnAppoinment.IconVisible = true;
            this.btnAppoinment.IconZoom = 75D;
            this.btnAppoinment.IsTab = false;
            this.btnAppoinment.Location = new System.Drawing.Point(366, 593);
            this.btnAppoinment.Name = "btnAppoinment";
            this.btnAppoinment.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnAppoinment.OnHovercolor = System.Drawing.Color.Firebrick;
            this.btnAppoinment.OnHoverTextColor = System.Drawing.Color.White;
            this.btnAppoinment.selected = false;
            this.btnAppoinment.Size = new System.Drawing.Size(214, 40);
            this.btnAppoinment.TabIndex = 61;
            this.btnAppoinment.Text = "Go to Appointment";
            this.btnAppoinment.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAppoinment.Textcolor = System.Drawing.Color.White;
            this.btnAppoinment.TextFont = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAppoinment.Click += new System.EventHandler(this.btnAppoinment_Click);
            // 
            // docID
            // 
            this.docID.DataPropertyName = "trtmntID";
            this.docID.HeaderText = "ID";
            this.docID.Name = "docID";
            this.docID.Width = 70;
            // 
            // trtmntName
            // 
            this.trtmntName.DataPropertyName = "name";
            this.trtmntName.HeaderText = "Treatment";
            this.trtmntName.Name = "trtmntName";
            this.trtmntName.Width = 200;
            // 
            // docNIC
            // 
            this.docNIC.DataPropertyName = "amount";
            dataGridViewCellStyle6.Format = "N2";
            dataGridViewCellStyle6.NullValue = null;
            this.docNIC.DefaultCellStyle = dataGridViewCellStyle6;
            this.docNIC.HeaderText = "Amount";
            this.docNIC.Name = "docNIC";
            this.docNIC.Width = 120;
            // 
            // ucDoctorDashBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.pnlAppointment);
            this.Controls.Add(this.pnlTreatment);
            this.Name = "ucDoctorDashBoard";
            this.Size = new System.Drawing.Size(900, 650);
            this.Load += new System.EventHandler(this.ucDoctorDashBoard_Load);
            this.pnlAppointment.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.patientGrid)).EndInit();
            this.pnlTreatment.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.treatmentGrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlAppointment;
        private Bunifu.Framework.UI.BunifuFlatButton btnAll;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.DataGridView patientGrid;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn patID;
        private System.Windows.Forms.DataGridViewTextBoxColumn fullname;
        private System.Windows.Forms.DataGridViewTextBoxColumn patContact;
        private System.Windows.Forms.DataGridViewTextBoxColumn AppointmentDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn status;
        private System.Windows.Forms.Panel pnlTreatment;
        private Bunifu.Framework.UI.BunifuFlatButton btnAppoinment;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.DataGridView treatmentGrid;
        private System.Windows.Forms.Button btnAddNew;
        private System.Windows.Forms.Label lblDetails;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridViewTextBoxColumn docID;
        private System.Windows.Forms.DataGridViewTextBoxColumn trtmntName;
        private System.Windows.Forms.DataGridViewTextBoxColumn docNIC;
    }
}

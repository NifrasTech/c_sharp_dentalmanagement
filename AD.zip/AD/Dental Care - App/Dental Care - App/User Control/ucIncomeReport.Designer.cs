﻿namespace Dental_Care___App.User_Control
{
    partial class ucIncomeReport
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.TreatmentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsetIncome = new Dental_Care___App.dsetIncome();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.doctorGrid = new System.Windows.Forms.DataGridView();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dsetIncomeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.TreatmentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsetIncome)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctorGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsetIncomeBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // TreatmentBindingSource
            // 
            this.TreatmentBindingSource.DataMember = "Treatment";
            this.TreatmentBindingSource.DataSource = this.dsetIncome;
            // 
            // dsetIncome
            // 
            this.dsetIncome.DataSetName = "dsetIncome";
            this.dsetIncome.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer1
            // 
            reportDataSource1.Name = "Income";
            reportDataSource1.Value = this.TreatmentBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "Dental_Care___App.rptIncome.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(398, 89);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.ShowBackButton = false;
            this.reportViewer1.ShowFindControls = false;
            this.reportViewer1.ShowPageNavigationControls = false;
            this.reportViewer1.ShowRefreshButton = false;
            this.reportViewer1.ShowStopButton = false;
            this.reportViewer1.ShowZoomControl = false;
            this.reportViewer1.Size = new System.Drawing.Size(483, 558);
            this.reportViewer1.TabIndex = 1;
            // 
            // doctorGrid
            // 
            this.doctorGrid.AllowUserToAddRows = false;
            this.doctorGrid.AllowUserToDeleteRows = false;
            this.doctorGrid.AllowUserToResizeColumns = false;
            this.doctorGrid.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(34)))), ((int)(((byte)(37)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White;
            this.doctorGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.doctorGrid.BackgroundColor = System.Drawing.Color.White;
            this.doctorGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.doctorGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.doctorGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(34)))), ((int)(((byte)(37)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.doctorGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.doctorGrid.ColumnHeadersHeight = 30;
            this.doctorGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.doctorGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.name});
            this.doctorGrid.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.HotTrack;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.doctorGrid.DefaultCellStyle = dataGridViewCellStyle3;
            this.doctorGrid.EnableHeadersVisualStyles = false;
            this.doctorGrid.GridColor = System.Drawing.Color.White;
            this.doctorGrid.Location = new System.Drawing.Point(24, 157);
            this.doctorGrid.MultiSelect = false;
            this.doctorGrid.Name = "doctorGrid";
            this.doctorGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.doctorGrid.RowHeadersVisible = false;
            this.doctorGrid.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White;
            this.doctorGrid.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.doctorGrid.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(34)))), ((int)(((byte)(37)))));
            this.doctorGrid.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.HotTrack;
            this.doctorGrid.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.White;
            this.doctorGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.doctorGrid.ShowCellToolTips = false;
            this.doctorGrid.Size = new System.Drawing.Size(321, 313);
            this.doctorGrid.TabIndex = 50;
            this.doctorGrid.TabStop = false;
            this.doctorGrid.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.doctorGrid_CellDoubleClick);
            // 
            // id
            // 
            this.id.DataPropertyName = "docID";
            this.id.HeaderText = "ID";
            this.id.Name = "id";
            this.id.Width = 70;
            // 
            // name
            // 
            this.name.DataPropertyName = "FullName";
            this.name.HeaderText = "Name";
            this.name.Name = "name";
            this.name.Width = 250;
            // 
            // dsetIncomeBindingSource
            // 
            this.dsetIncomeBindingSource.DataSource = this.dsetIncome;
            this.dsetIncomeBindingSource.Position = 0;
            // 
            // dtpDate
            // 
            this.dtpDate.CalendarFont = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDate.CalendarForeColor = System.Drawing.Color.White;
            this.dtpDate.CalendarMonthBackground = System.Drawing.SystemColors.MenuHighlight;
            this.dtpDate.CalendarTitleBackColor = System.Drawing.SystemColors.MenuHighlight;
            this.dtpDate.CalendarTitleForeColor = System.Drawing.Color.White;
            this.dtpDate.CalendarTrailingForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.dtpDate.CustomFormat = "yyyy/MM/dd";
            this.dtpDate.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.dtpDate.Font = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDate.Location = new System.Drawing.Point(24, 119);
            this.dtpDate.MaxDate = new System.DateTime(3000, 12, 31, 0, 0, 0, 0);
            this.dtpDate.MinDate = new System.DateTime(1800, 1, 1, 0, 0, 0, 0);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dtpDate.Size = new System.Drawing.Size(321, 32);
            this.dtpDate.TabIndex = 51;
            this.dtpDate.Value = new System.DateTime(2019, 8, 13, 0, 0, 0, 0);
            // 
            // ucIncomeReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.dtpDate);
            this.Controls.Add(this.doctorGrid);
            this.Controls.Add(this.reportViewer1);
            this.Name = "ucIncomeReport";
            this.Size = new System.Drawing.Size(900, 650);
            this.Load += new System.EventHandler(this.ucIncomeReport_Load);
            ((System.ComponentModel.ISupportInitialize)(this.TreatmentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsetIncome)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctorGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsetIncomeBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.DataGridView doctorGrid;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.BindingSource TreatmentBindingSource;
        private dsetIncome dsetIncome;
        private System.Windows.Forms.BindingSource dsetIncomeBindingSource;
        private System.Windows.Forms.DateTimePicker dtpDate;
    }
}

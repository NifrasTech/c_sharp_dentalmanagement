﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App.User_Control
{
    public partial class ucDoctorForm : UserControl
    {
        Validation valid = new Validation();
        Animation anim = new Animation();
        Doctor doctor = new Doctor();
        Functions function = new Functions();
        public ucDoctorForm()
        {
            InitializeComponent();
            valid.placeHolder(pnlForm);
            valid.numbersOnly(txtContact);
        }


        private void ucDoctorForm_Load(object sender, EventArgs e)
        {
            lblFormTitle.Text = Animation.lblFormMode; // Form mode can be Add new Patient or Update
            if (Animation.lblFormMode == "Add New Doctor")
            {
                string id;
                DataTable dTable = new DataTable();

                dTable = function.fillData("select MAX(docID) from Doctor");
                id = dTable.Rows[0].ItemArray[0].ToString();

                if (id == "")
                {
                    function.ExecuteQuery("TRUNCATE TABLE Doctor");
                }

                valid.GenerateID(txtUsername, "select MAX(docID) from Doctor");
                id = "DOC"+txtUsername.Text;
                txtUsername.Text = id;
                Doctor.txtID = txtUsername;
                txtUsername.Enabled = false;
                btnUpdate.Visible = false;
                btnSave.Visible = true;
                lblUserName.Visible = true;
                txtUsername.Visible = true;
            }
            else
            {
                txtUsername.Enabled = false;
                lblUserName.Visible = false;
                txtUsername.Visible = false;
                lblFormTitle.Text = Animation.lblFormMode;
                setTextBox();
                btnSave.Visible = false;
                btnUpdate.Visible = true;
            }
        }

        void setTextBox()
        {
            valid.setTextBoxColor(pnlForm);
            txtFirstName.Text = PublicClass.docFirstName;
            txtLastName.Text = PublicClass.docLastName;
            txtNIC.Text = PublicClass.docNIC;
            txtContact.Text = PublicClass.docContact;
            dtpDOB.Text = PublicClass.docDOB;
            dtpExp.Text = PublicClass.docExp;
            txtContact.Text = PublicClass.docContact;
            txtAddress.Text = PublicClass.docAddress;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            anim.formAnimation("Close", "Add New Doctor");
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            doctor.Exp = dtpExp.Text.Trim();
            if (valid.textBoxEmpty(pnlForm))
            {
               
                doctor.FirstName = txtFirstName.Text.Trim();
                doctor.LastName = txtLastName.Text.Trim();
                doctor.NIC = txtNIC.Text.Trim();
                doctor.Contact = txtContact.Text.Trim();
                doctor.Address = txtAddress.Text.Trim();
                doctor.DOB = dtpDOB.Text;
                doctor.saveDoc();
                anim.formAnimation("Close", "Add New Doctor");
                valid.clearAllTextBox(pnlForm);
            }

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            doctor.Exp = dtpExp.Text.Trim();
            if (valid.textBoxEmpty(pnlForm))
            {
                doctor.ID = PublicClass.docID;
                doctor.FirstName = txtFirstName.Text.Trim();
                doctor.LastName = txtLastName.Text.Trim();
                doctor.NIC = txtNIC.Text.Trim();
                doctor.Contact = txtContact.Text.Trim();
                doctor.Address = txtAddress.Text.Trim();
                doctor.DOB = dtpDOB.Text;
                doctor.updateDoc();
                anim.formAnimation("Close", "Edit Doctor");
            }
        }

        private void pnlForm_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

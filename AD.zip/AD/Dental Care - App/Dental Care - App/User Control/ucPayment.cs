﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using System.Drawing.Printing;

namespace Dental_Care___App.User_Control
{
    public partial class ucPayment : UserControl
    {
        Validation validation = new Validation();
        Animation animation = new Animation();
        Functions function = new Functions();
        Payment payment = new Payment();

        public ucPayment()
        {
            InitializeComponent();
            validation.placeHolder(pnlSearch);
            validation.numbersOnly(txtSearch);
        }

        decimal total=0;
        private void btnPay_Click(object sender, EventArgs e)
        {
            payment.AppointID = PublicClass.appointID;
            if(payment.viewPayment())
            { 
                payment.Amount = total;
                payment.Date = DateTime.Now.ToString("yyyy/MM/d");
                payment.addPayment();
            }
            else
            {
                animation.messageBox("The patient already Paid",false);
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {

            string id = txtSearch.Text;
            Report report = new Report();
            PublicClass.totalParameter = String.Format("{0:0.00}", total);
            report.ShowDialog();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if(validation.textBoxEmpty(pnlSearch))
            { 
                DataTable dataTable = new DataTable();
                string query = "EXEC getPatandDoc @id="+txtSearch.Text+"";
                dataTable = function.fillData(query);

                if (dataTable.Rows.Count == 0)
                {
                    treatmentGrid.Visible = false;
                    animation.messageBox("No Data Found", false);
                    lblPatient.Text = "Doctor Name";
                    lblDoctor.Text = "Patient Name";
                    lblTotal.Text = "Total Amount";
                    btnPrint.Enabled = false;
                    btnPay.Enabled = false;
                    treatmentGrid.DataSource = dataTable;
                }
                else
                {
                    PublicClass.appointID = Convert.ToInt32(txtSearch.Text);
                    lblDoctor.Text="Doctor : "+dataTable.Rows[0].ItemArray[1].ToString();
                    lblPatient.Text = "Patient : " + dataTable.Rows[0].ItemArray[0].ToString();

                    query = "EXEC getTreatment @id="+txtSearch.Text+"";
                    treatmentGrid.DataSource = function.fillData(query);

                    total = 0;
                    for(int i=0; i<treatmentGrid.Rows.Count; i++)
                    {
                        total += Convert.ToDecimal(treatmentGrid.Rows[i].Cells[3].Value.ToString());
                    }

                    lblTotal.Text = "The Total Amount Is : "+ String.Format("{0:0.00}", total);
                    btnPrint.Enabled = true;
                    btnPay.Enabled = true;
                    treatmentGrid.Visible = true;
                }
            }
        }

        private void ucPayment_Load(object sender, EventArgs e)
        {
            treatmentGrid.Visible = false;
            btnPrint.Enabled = false;
            btnPay.Enabled = false;
        }
    }
}

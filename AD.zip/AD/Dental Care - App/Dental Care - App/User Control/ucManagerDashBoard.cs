﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App.User_Control
{
    public partial class ucManagerDashBoard : UserControl
    {
        Animation animation = new Animation();
        public ucManagerDashBoard()
        {
            InitializeComponent();
        }

        private void btnClickHere_Click(object sender, EventArgs e)
        {
            ucManagerMenu ucManager = new ucManagerMenu();
            Animation.pnlMenu.Controls.Clear();
            Animation.pnlMenu.Controls.Add(ucManager);
            animation.menuAnimation("Open");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App.User_Control
{
    public partial class ucPatientForm : UserControl
    {
        Validation valid = new Validation();
        public ucPatientForm()
        {
            InitializeComponent();
            valid.placeHolder(pnlForm);
            valid.numbersOnly(txtContact);
        }

        Animation anim = new Animation();
        Patient objPatient = new Patient();

        private void btnCancel_Click(object sender, EventArgs e)
        {
            anim.formAnimation("Close", "Add New Patient");
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if(valid.textBoxEmpty(pnlForm))
            {
                objPatient.FirstName = txtFirstName.Text.Trim();
                objPatient.LastName = txtLastName.Text.Trim();
                objPatient.NIC = txtNIC.Text.Trim();
                objPatient.Contact = txtContact.Text.Trim();
                objPatient.Address = txtAddress.Text.Trim();
                objPatient.savePatient();
                valid.clearAllTextBox(pnlForm);
                txtFirstName.Focus();
            }

            //anim.formAnimation("Close");
        }

        private void ucPatientForm_Load(object sender, EventArgs e)
        {
            lblFormTitle.Text = Animation.lblFormMode; // Form mode can be Add new Patient or Update
            if(Animation.lblFormMode == "Add New Patient")
            {
                btnUpdate.Visible = false;
                btnSave.Visible = true;
            }
            else
            {
                lblFormTitle.Text = Animation.lblFormMode;
                setTextBox();
                btnSave.Visible = false;
                btnUpdate.Visible = true;
            }
            
        }

        //Filling the textBox and change text Color
        void setTextBox()
        {
            valid.setTextBoxColor(pnlForm); //Change textbox text color
            txtFirstName.Text = PublicClass.patFirstName;
            txtLastName.Text = PublicClass.patLastName;
            txtNIC.Text = PublicClass.patNIC;
            txtContact.Text = PublicClass.patContact;
            txtAddress.Text = PublicClass.patAddress;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (valid.textBoxEmpty(pnlForm))
            {
                objPatient.ID = PublicClass.patID;
                objPatient.FirstName = txtFirstName.Text.Trim();
                objPatient.LastName = txtLastName.Text.Trim();
                objPatient.NIC = txtNIC.Text.Trim();
                objPatient.Contact = txtContact.Text.Trim();
                objPatient.Address = txtAddress.Text.Trim();

                objPatient.updatePatient();
                anim.formAnimation("Close", "Edit Patient");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App.User_Control
{
    public partial class ucStaff : UserControl
    {
        Functions function = new Functions();
        Animation animation = new Animation();
        Validation validation = new Validation();
        Staff staff = new Staff();

        public ucStaff()
        {
            InitializeComponent();
            validation.placeHolder(pnlForm);
            validation.numbersOnly(txtContact);
        }

        private void ucStaff_Load(object sender, EventArgs e)
        {
            dtpDOB.Value = DateTime.Today;
            staff.DOB = dtpDOB.Text;
            pnlView.Location = new Point(0, 0);
            pnlForm.Top = this.Height;
            PublicClass.dataGrid = staffGrid;
            staff.viewStaff(staffGrid);
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            validation.EnableTextBox(pnlForm);
            txtID.Enabled = false;
            dtpDOB.Enabled = true;
            combobox.Enabled = false;
            btnUpdate.Visible = true;
            btnSave.Visible = false;
            btnUpdate.Enabled = true;
            btnEdit.Enabled = false;

        }

        private void staffGrid_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            controlEdit();
            int id = Convert.ToInt32(staffGrid.SelectedRows[0].Cells[0].Value.ToString());
            DataTable dtable = new DataTable();

            string query = "select * from Staff where id="+id+"";
            dtable = function.fillData(query);

            //Set Text Box for Update
            txtID.Text = dtable.Rows[0].ItemArray[0].ToString();
            txtFirstName.Text = dtable.Rows[0].ItemArray[1].ToString();
            txtLastName.Text = dtable.Rows[0].ItemArray[2].ToString();
            txtNIC.Text = dtable.Rows[0].ItemArray[3].ToString();
            dtpDOB.Text = dtable.Rows[0].ItemArray[4].ToString();
            txtContact.Text = dtable.Rows[0].ItemArray[5].ToString();
            txtAddress.Text = dtable.Rows[0].ItemArray[6].ToString();
            combobox.Text = dtable.Rows[0].ItemArray[7].ToString();

            if(combobox.Text == "Manager" || combobox.Text == "Front Officer")
            {
                lblUserName.Visible = false;
                txtUserName.Visible = false;
            }
            else
            {
                lblUserName.Visible = false;
                txtUserName.Visible = false;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            animation.changePanel(pnlView, pnlForm, false);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            validation.EnableTextBox(pnlForm);
            validation.clearAllTextBox(pnlForm);
            controlAdd();

            string id;
            DataTable dTable = new DataTable();

            dTable = function.fillData("select MAX(id) from Staff");
            id = dTable.Rows[0].ItemArray[0].ToString();

            if (id == "")
            {
                function.ExecuteQuery("TRUNCATE TABLE Staff");
            }

            validation.GenerateID(txtID, "select MAX(id) from Staff");
            animation.changePanel(pnlView, pnlForm, true);
        }


        void controlAdd()
        {
            dtpDOB.Value = DateTime.Today;
            combobox.Text = "";
            txtID.Enabled = false;
            txtUserName.Enabled = false;
            dtpDOB.Enabled = true;
            combobox.Enabled = true;
            btnUpdate.Visible = false;
            btnSave.Visible = true;
            btnEdit.Enabled = false;
            lblUserName.Visible = false;
            txtUserName.Visible = false;
        }

        void controlEdit()
        {
            validation.disableTextBox(pnlForm);
            txtUserName.Enabled = false;
            btnEdit.Enabled = true;
            btnUpdate.Enabled = false;
            btnUpdate.Visible = true;
            btnSave.Visible = false;
            dtpDOB.Enabled = false;
            combobox.Enabled = false;
            validation.setTextBoxColor(pnlForm); //Change textbox text color
            animation.changePanel(pnlView, pnlForm, true);
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (validation.textBoxEmpty(pnlForm))
            {
                staff.ID = Convert.ToInt32(txtID.Text);
                staff.FirstName = txtFirstName.Text.Trim();
                staff.LastName = txtLastName.Text.Trim();
                staff.NIC = txtNIC.Text.Trim();
                staff.DOB = dtpDOB.Text.Trim();
                staff.Contact = txtContact.Text.Trim();
                staff.Address = txtAddress.Text.Trim();
                staff.Designation = combobox.Text.Trim();

                staff.updateStaff();
            }
        }

        private void combobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (combobox.Text == "Manager" || combobox.Text == "Front Officer")
            {
                lblUserName.Visible = true;
                txtUserName.Visible = true;
                txtUserName.Enabled = false;
                if(btnUpdate.Visible == false || btnUpdate.Enabled == true)
                {

                    if (combobox.Text == "Front Officer")
                    {
                        txtUserName.Text = "OFF" + txtID.Text;
                    }
                    else
                    {
                        txtUserName.Text = "MAN" + txtID.Text;
                    }
                }
            }
            else
            {
                lblUserName.Visible = false;
                txtUserName.Visible = false;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            staff.ID = Convert.ToInt32(staffGrid.SelectedRows[0].Cells[0].Value.ToString());
            staff.Designation = staffGrid.SelectedRows[0].Cells[3].Value.ToString();
            staff.deleteStaff();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (validation.textBoxEmpty(pnlForm))
            {
                Staff.username = txtUserName.Text;
                staff.FirstName = txtFirstName.Text;
                staff.LastName = txtLastName.Text;
                staff.NIC = txtNIC.Text;
                staff.DOB = dtpDOB.Text;
                staff.Contact = txtContact.Text;
                staff.Address = txtAddress.Text;
                staff.Designation = combobox.Text;

                staff.addStaff();
                animation.changePanel(pnlView, pnlForm, false);
            }
        }
    }
}

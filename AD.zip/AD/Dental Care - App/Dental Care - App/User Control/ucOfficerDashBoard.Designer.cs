﻿namespace Dental_Care___App.User_Control
{
    partial class ucOfficerDashBoard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucOfficerDashBoard));
            this.lblWelcome = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnClickHere = new Bunifu.Framework.UI.BunifuFlatButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblWelcome
            // 
            this.lblWelcome.BackColor = System.Drawing.Color.Transparent;
            this.lblWelcome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblWelcome.Font = new System.Drawing.Font("Calibri", 40F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.ForeColor = System.Drawing.Color.DodgerBlue;
            this.lblWelcome.Location = new System.Drawing.Point(130, 387);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(648, 160);
            this.lblWelcome.TabIndex = 7;
            this.lblWelcome.Text = "Specialized Dental Care (SDC)";
            this.lblWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Calibri", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(63, 322);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(775, 65);
            this.bunifuCustomLabel1.TabIndex = 7;
            this.bunifuCustomLabel1.Text = "Welcome to";
            this.bunifuCustomLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(182, 108);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(506, 223);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // btnClickHere
            // 
            this.btnClickHere.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnClickHere.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnClickHere.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnClickHere.BorderRadius = 7;
            this.btnClickHere.ButtonText = "Click Here to The Menu";
            this.btnClickHere.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClickHere.DisabledColor = System.Drawing.Color.Gray;
            this.btnClickHere.Iconcolor = System.Drawing.Color.Transparent;
            this.btnClickHere.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnClickHere.Iconimage")));
            this.btnClickHere.Iconimage_right = null;
            this.btnClickHere.Iconimage_right_Selected = null;
            this.btnClickHere.Iconimage_Selected = null;
            this.btnClickHere.IconMarginLeft = 0;
            this.btnClickHere.IconMarginRight = 0;
            this.btnClickHere.IconRightVisible = true;
            this.btnClickHere.IconRightZoom = 0D;
            this.btnClickHere.IconVisible = true;
            this.btnClickHere.IconZoom = 70D;
            this.btnClickHere.IsTab = false;
            this.btnClickHere.Location = new System.Drawing.Point(324, 552);
            this.btnClickHere.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnClickHere.Name = "btnClickHere";
            this.btnClickHere.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnClickHere.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnClickHere.OnHoverTextColor = System.Drawing.Color.White;
            this.btnClickHere.selected = false;
            this.btnClickHere.Size = new System.Drawing.Size(288, 59);
            this.btnClickHere.TabIndex = 9;
            this.btnClickHere.Text = "Click Here to The Menu";
            this.btnClickHere.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClickHere.Textcolor = System.Drawing.Color.White;
            this.btnClickHere.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClickHere.Click += new System.EventHandler(this.btnClickHere_Click);
            // 
            // ucOfficerDashBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.btnClickHere);
            this.Controls.Add(this.bunifuCustomLabel1);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.pictureBox1);
            this.Name = "ucOfficerDashBoard";
            this.Size = new System.Drawing.Size(900, 650);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuCustomLabel lblWelcome;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.Framework.UI.BunifuFlatButton btnClickHere;
    }
}

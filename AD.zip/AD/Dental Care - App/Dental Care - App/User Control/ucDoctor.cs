﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App.User_Control
{
    public partial class ucDoctor : UserControl
    {
        Doctor doctor = new Doctor();
        Animation anim = new Animation();
        Functions function = new Functions();
        public ucDoctor()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            ucDoctorForm doctorForm = new ucDoctorForm();
            Animation.pnlFormLoader.Controls.Clear();
            anim.formAnimation("Open", "Add New Doctor");
            Animation.pnlFormLoader.Controls.Add(doctorForm);
        }

        private void ucDoctor_Load(object sender, EventArgs e)
        {
            PublicClass.dataGrid = doctorGrid;
            doctor.viewDoc(doctorGrid);
            btnPrint.Visible = true;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            doctor.ID = Convert.ToInt32(doctorGrid.SelectedRows[0].Cells[0].Value.ToString());
            doctor.deleteDoc();
        }

        private void doctorGrid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            doctor.ID = Convert.ToInt32(doctorGrid.SelectedRows[0].Cells[0].Value.ToString());
            doctor.FirstName = doctorGrid.SelectedRows[0].Cells[1].Value.ToString();
            doctor.LastName = doctorGrid.SelectedRows[0].Cells[2].Value.ToString();
            doctor.NIC = doctorGrid.SelectedRows[0].Cells[3].Value.ToString();
            doctor.DOB = doctorGrid.SelectedRows[0].Cells[4].Value.ToString();
            doctor.Exp = doctorGrid.SelectedRows[0].Cells[5].Value.ToString();
            doctor.Contact = doctorGrid.SelectedRows[0].Cells[6].Value.ToString();
            doctor.Address = doctorGrid.SelectedRows[0].Cells[7].Value.ToString();

            setValue();

            ucDoctorForm doctorForm = new ucDoctorForm();
            Animation.pnlFormLoader.Controls.Clear();
            anim.formAnimation("Open", "Edit Doctor Details");
            Animation.pnlFormLoader.Controls.Add(doctorForm);
        }

        void setValue()
        {
            PublicClass.docID = doctor.ID;
            PublicClass.docFirstName = doctor.FirstName;
            PublicClass.docLastName = doctor.LastName;
            PublicClass.docNIC = doctor.NIC;
            PublicClass.docDOB = doctor.DOB;
            DataTable dTable = new DataTable();
            dTable = function.fillData("select exp from Doctor where docID=" + doctor.ID + "");
            PublicClass.docExp = dTable.Rows[0].ItemArray[0].ToString();
            PublicClass.docContact = doctor.Contact;
            PublicClass.docAddress = doctor.Address;
    }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            string query = "select docID, FirstName, LastName, NIC, DOB, DATEDIFF(YEAR, exp, GETDATE()) as exp, contact, address from Doctor";
            DataTable dTable = new DataTable();
            dTable = function.fillData(query);
            DataView dView = new DataView(dTable);
            dView.Sort = "exp desc";
            doctorGrid.DataSource = dView;
            //dataGrid.DataSource = dTable;
        }
    }
}

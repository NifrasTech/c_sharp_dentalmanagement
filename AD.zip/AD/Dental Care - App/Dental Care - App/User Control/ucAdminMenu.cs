﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App.User_Control
{
    public partial class ucAdminMenu : UserControl
    {
        Animation anim = new Animation();
        public ucAdminMenu()
        {
            InitializeComponent();
        }

        private void btnSetting_Click(object sender, EventArgs e)
        {
            ucChangePassword password = new ucChangePassword();
            Animation.pnlContent.Controls.Clear();
            Animation.pnlContent.Controls.Add(password);
            anim.menuAnimation("Close");
        }

        private void btnStaff_Click(object sender, EventArgs e)
        {
            ucStaff staff = new ucStaff();
            Animation.pnlContent.Controls.Clear();
            Animation.pnlContent.Controls.Add(staff);
            anim.menuAnimation("Close");
        }

        private void btnDoctor_Click(object sender, EventArgs e)
        {
            ucDoctor doctor = new ucDoctor();
            Animation.pnlContent.Controls.Clear();
            Animation.pnlContent.Controls.Add(doctor);
            anim.menuAnimation("Close");
        }
    }
}

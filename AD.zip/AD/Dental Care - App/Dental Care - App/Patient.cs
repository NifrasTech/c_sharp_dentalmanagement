using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_Care___App
{
   class Patient
    {
        private int id;
        private string firstname;
        private string lastname;
        private string nic;
        private string contact;
        private string address;

        Functions function = new Functions();
        Animation animation = new Animation();

        public int ID
        {
            get { return id; }
            set { id = value; }
        }

        public string FirstName
        {
            get { return firstname; }
            set { firstname = value; }
        }

        public string LastName
        {
            get { return lastname; }
            set { lastname = value; }
        }

        public string NIC
        {
            get { return nic; }
            set { nic = value; }
        }

        public string Contact
        {
            get { return contact; }
            set { contact = value; }
        }

        public string Address
        {
            get { return address; }
            set { address = value; }
        }

        string query;
        public void savePatient()
        {
            query = "insert into Patient (firstName, Lastname, nic, contactNo,address) values ('"+firstname+ "', '" + lastname + "','" + nic + "','" + contact + "','" + address + "')";
            function.ExecuteQuery(query);
            viewPatient(PublicClass.dataGrid);
            animation.messageBox("Successfully Saved", true);
        }

        public void viewPatient(DataGridView dataGrid)
        {
            query = "select * from Patient";
            DataTable dTable = new DataTable();
            dTable=function.fillData(query);
            dataGrid.DataSource = dTable;
        }

        public void deletePatient()
        {
            query = "delete from Patient where patientID = "+id+"";
            function.ExecuteQuery(query);
            viewPatient(PublicClass.dataGrid);
            animation.messageBox("Successfully Deleted", true);
        }

        public void updatePatient()
        {
            query = "update Patient set firstName='"+firstname+ "', Lastname='" + lastname + "', nic='" + nic + "', contactNo='" + contact + "',address='" + address + "' where patientID="+id+"";
            function.ExecuteQuery(query);
            viewPatient(PublicClass.dataGrid);
            animation.messageBox("Successfully Updated", true);
        }
    }
}

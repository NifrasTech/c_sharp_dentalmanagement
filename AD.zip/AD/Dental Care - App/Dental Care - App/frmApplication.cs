﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Transitions;
using Dental_Care___App.User_Control;

namespace Dental_Care___App
{
    public partial class frmApplication : Form
    {
        public frmApplication()
        {
            InitializeComponent();
        }

        void setSize (Panel tmpPanel)
        {
            int width = this.Width;
            int height = this.Height;
            tmpPanel.Width = width;
            tmpPanel.Height = height;
            tmpPanel.Location = new Point(0, -height); 
        }

        void setControls() //Set All Main Controls to the Class
        {
            Animation.pbMenuClose = pbCloseMenu;
            Animation.pbMenuOpen = pbMenu;
            Animation.pnlContent = pnlContent;
            Animation.pnlMenu = pnlMenu;
            Animation.pnlFormLoader = pnlForm;
            Animation.pbLogout = pbLogout;
        }

        Animation animation = new Animation(); // Create an Object of Animation class
        private void frmApplication_Load(object sender, EventArgs e)
        {
            Animation.pnlMessage = pnlMessage;
            pnlMessage.Left = this.Width;

            setSize(pnlMenu); //Set Menu Panel to the Form Size
            setSize(pnlContent); //Set Menu Panel to the Form Size
            setSize(pnlForm);
            pnlContent.Location = new Point(0,0);
            pnlForm.Location = new Point(0, pnlForm.Height);
            pbCloseMenu.Location = new Point(421, -pbCloseMenu.Height); //Close Menu Button Hidden by Default
            setControls();

            //Set Dashboard after login by their role
            ucOfficerDashBoard officerDash = new ucOfficerDashBoard();
            ucManagerDashBoard managerDash = new ucManagerDashBoard();
            ucDoctorDashBoard doctorDash = new ucDoctorDashBoard();
            ucAdmin admin = new ucAdmin();
            if (User.userRole == "Front Officer")
            {
                ucFrontOfficerMenu ucFrontOfficer = new ucFrontOfficerMenu();
                pnlMenu.Controls.Clear();
                pnlMenu.Controls.Add(ucFrontOfficer);
                pnlContent.Controls.Clear();
                pnlContent.Controls.Add(officerDash);
            }
            else if (User.userRole == "Manager")
            {
                ucManagerMenu ucManager = new ucManagerMenu();
                pnlMenu.Controls.Clear();
                pnlMenu.Controls.Add(ucManager);
                pnlContent.Controls.Clear();
                pnlContent.Controls.Add(managerDash);
            }
            else if(User.userRole=="Admin")
            {
                ucAdminMenu ucAdmin = new ucAdminMenu();
                pnlMenu.Controls.Clear();
                pnlMenu.Controls.Add(ucAdmin);
                pnlContent.Controls.Clear();
                pnlContent.Controls.Add(admin);
            }
            else
            {
                ucDoctorMenu ucDoctor = new ucDoctorMenu();
                pnlMenu.Controls.Clear();
                pnlMenu.Controls.Add(ucDoctor);
                pnlContent.Controls.Clear();
                pnlContent.Controls.Add(doctorDash);
            }
        }

        private void pbMenu_Click(object sender, EventArgs e)
        {
            if(User.userRole == "Manager") // Manager Menu
            { 
                ucManagerMenu ucManager = new ucManagerMenu();
                pnlMenu.Controls.Clear();
                pnlMenu.Controls.Add(ucManager);
            }
            else if (User.userRole == "Front Officer") // Front Officer Menu
            {
                ucFrontOfficerMenu ucFrontOfficer = new ucFrontOfficerMenu();
                pnlMenu.Controls.Clear();
                pnlMenu.Controls.Add(ucFrontOfficer);
            }
            else if (User.userRole == "Doctor") // Doctor Menu
            {
                ucDoctorMenu ucDoctor = new ucDoctorMenu();
                pnlMenu.Controls.Clear();
                pnlMenu.Controls.Add(ucDoctor);
            }
            else if (User.userRole == "Admin") // Amdin Menu
            {
                ucAdminMenu ucAdmin = new ucAdminMenu();
                pnlMenu.Controls.Clear();
                pnlMenu.Controls.Add(ucAdmin);
            }
            animation.menuAnimation("Open"); //Run Transition

        }

        private void pbCloseMenu_Click(object sender, EventArgs e)
        {
            animation.menuAnimation("Close");
        }

        private void pbLogout_Click(object sender, EventArgs e)
        {
            setSize(pnlMenu); //Set Menu Panel to the Form Size
            setSize(pnlContent); //Set Menu Panel to the Form Size
            pnlContent.Location = new Point(0, 0);
            pbCloseMenu.Location = new Point(421, -pbCloseMenu.Height); //Close Menu Button Hidden by Default
            animation.menuAnimation("Close");
            this.Close();
        }
    }
}

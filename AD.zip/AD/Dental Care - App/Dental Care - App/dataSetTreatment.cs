﻿namespace Dental_Care___App
{
}

namespace Dental_Care___App {
    
    
    public partial class dataSetTreatment {
    }
}
namespace Dental_Care___App {
    
    
    public partial class dataSetTreatment {
    }
}

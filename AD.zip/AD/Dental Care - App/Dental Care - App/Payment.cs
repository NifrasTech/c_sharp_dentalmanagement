﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dental_Care___App
{
    class Payment
    {

        private int id;
        private int appointID;
        private decimal amount;
        private string date;

        Functions function = new Functions();
        Animation animation = new Animation();

        public int ID
        {
            get { return id; }
            set { id = value; }
        }
        public int AppointID
        {
            get { return appointID; }
            set { appointID = value; }
        }

        public decimal Amount
        {
            get { return amount; }
            set { amount = value; }
        }

        public string Date
        {
            get { return date; }
            set { date = value; }
        }

        string query;
        public void addPayment()
        {
            query = "insert into Payment (appointID,amount,date) values ("+appointID+", " + amount + ", '" + date + "')";
            function.ExecuteQuery(query);
            animation.messageBox("Payment Recieved", true);
        }

        public bool viewPayment()
        {
            DataTable dTable = new DataTable();
            query = "select * from payment where appointID = "+appointID+"";
            dTable = function.fillData(query);
            if(dTable.Rows.Count==0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}

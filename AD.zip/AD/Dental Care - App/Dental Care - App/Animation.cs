﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;
using System.Media;
using Transitions;
using Dental_Care___App.User_Control;

namespace Dental_Care___App
{
    class Animation
    {
        public static Panel pnlMenu;
        public static Panel pnlContent;
        public static Panel pnlFormLoader;
        public static Panel pnlMessage;
        public static string lblFormMode;
        public static string message;
        public static PictureBox pbMenuOpen;
        public static PictureBox pbMenuClose;
        public static PictureBox pbLogout;


        public void menuAnimation(String mode) //Menu Animation can be Open or Close
        {

            Transition trsn = new Transition(new TransitionType_CriticalDamping(1000));
            if(mode == "Open")
            {
                trsn.add(pbMenuOpen, "Top", -pbMenuOpen.Height);
                trsn.add(pbMenuClose, "Top", 5);
                trsn.add(pnlMenu, "Top", 0);
                trsn.run();
            }
            else
            {
                trsn.add(pbMenuOpen, "Top", 5);
                trsn.add(pbMenuClose, "Top", -pbMenuClose.Height);
                trsn.add(pnlMenu, "Top", -pnlMenu.Height);
                trsn.run();
            }
        }

        public void formAnimation(String mode, string formMode)
        {
            lblFormMode = formMode;
            Transition trsn = new Transition(new TransitionType_CriticalDamping(1000));
            if (mode == "Open")
            {
                trsn.add(pnlFormLoader, "Top", 0);
                trsn.add(pnlContent, "Top", pnlContent.Height);
                trsn.add(pbMenuOpen, "Top", -pbMenuOpen.Height);
                trsn.add(pbLogout, "Top", -pbLogout.Height);
                trsn.run();
            }
            else
            {
                trsn.add(pnlFormLoader, "Top", pnlFormLoader.Height);
                trsn.add(pnlContent, "Top", 0);
                trsn.add(pbMenuOpen, "Top", 5);
                trsn.add(pbLogout, "Top", 13);
                trsn.run();
            }
        }

        public void messageBox(string msg, bool mode)
        {
            message = msg;

            if(mode)
            {
                ucMessageBox messageBox = new ucMessageBox();
                pnlMessage.Controls.Clear();
                pnlMessage.Controls.Add(messageBox);
            }
            else
            {
                ucErrorMessage errorMessage = new ucErrorMessage();
                pnlMessage.Controls.Clear();
                pnlMessage.Controls.Add(errorMessage);
            }

            Transition trsn = new Transition(new TransitionType_CriticalDamping(2000));
            Transition trsn2 = new Transition(new TransitionType_Acceleration(5000));
            trsn.add(pnlMessage, "Left", 900-pnlMessage.Width);
            trsn2.add(pnlMessage, "Left", 900);
            Transition.runChain(trsn,trsn2);
        }

        public void changePanel(Panel panelOne, Panel panelTwo, bool mode)
        {
            if(mode)
            {
                Transition trsn = new Transition(new TransitionType_CriticalDamping(1000));
                trsn.add(panelOne, "Top", panelOne.Height);
                trsn.add(panelTwo, "Top", 0);
                trsn.run();
            }
            else
            {
                Transition trsn = new Transition(new TransitionType_CriticalDamping(1000));
                trsn.add(panelTwo, "Top", panelTwo.Height);
                trsn.add(panelOne, "Top", 0);
                trsn.run();
            }
        }

        public void LoginMessage(Label lblMessage, int top)
        {
            Transition trsn = new Transition(new TransitionType_CriticalDamping(2000));
            Transition trsn2 = new Transition(new TransitionType_Acceleration(4000));
            trsn.add(lblMessage, "Top", top);
            trsn2.add(lblMessage, "Top", lblMessage.Parent.Height);
            Transition.runChain(trsn, trsn2);
        }
    }
}
